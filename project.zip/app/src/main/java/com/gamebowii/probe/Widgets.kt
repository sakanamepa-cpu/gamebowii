package com.gamebowii.probe

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** A drawn cartridge: the label shows the game title and a loading bar fills while it is read. */
class CartridgeView(context: Context) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    var title: String = ""
        set(v) {
            field = v
            invalidate()
        }

    var progress: Int = 0
        set(v) {
            field = if (v < 0) 0 else if (v > 100) 100 else v
            invalidate()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((150 * d).toInt(), (172 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 6 * d
        val bevel = 26 * d

        // body
        val body = Path()
        body.moveTo(m, m)
        body.lineTo(w - m - bevel, m)
        body.lineTo(w - m, m + bevel)
        body.lineTo(w - m, h - m)
        body.lineTo(m, h - m)
        body.close()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF78909C.toInt()
        canvas.save()
        canvas.translate(0f, 3 * d)
        canvas.drawPath(body, paint)
        canvas.restore()
        paint.color = 0xFFB0BEC5.toInt()
        canvas.drawPath(body, paint)

        // grip lines at the top
        paint.color = 0xFF90A4AE.toInt()
        var gx = m + 14 * d
        while (gx < w - m - bevel - 6 * d) {
            canvas.drawRect(gx, m + 6 * d, gx + 3 * d, m + 14 * d, paint)
            gx += 9 * d
        }

        // label
        val lx = m + 14 * d
        val lr = w - m - 14 * d
        val ly = m + 24 * d
        val lb = ly + h * 0.36f
        paint.color = 0xFFF5F0E1.toInt()
        canvas.drawRoundRect(RectF(lx, ly, lr, lb), 6 * d, 6 * d, paint)
        paint.color = 0xFF2E7D32.toInt()
        canvas.drawRoundRect(RectF(lx, ly, lr, ly + 12 * d), 6 * d, 6 * d, paint)
        canvas.drawRect(lx, ly + 6 * d, lr, ly + 12 * d, paint)

        // title in the label
        val shown = if (title.isEmpty()) "?" else title
        text.typeface = Typeface.DEFAULT_BOLD
        text.color = 0xFF263238.toInt()
        text.textAlign = Paint.Align.CENTER
        var size = 17 * d
        text.textSize = size
        val maxW = (lr - lx) - 12 * d
        while (text.measureText(shown) > maxW && size > 8 * d) {
            size -= 1f
            text.textSize = size
        }
        canvas.drawText(shown, (lx + lr) / 2f, ly + 12 * d + (lb - ly - 12 * d) / 2f + size / 3f, text)

        // loading bar
        val by = lb + 12 * d
        val bh = 10 * d
        paint.color = 0xFF546E7A.toInt()
        canvas.drawRoundRect(RectF(lx, by, lr, by + bh), bh / 2f, bh / 2f, paint)
        if (progress > 0) {
            paint.color = 0xFF66BB6A.toInt()
            val fw = (lr - lx) * progress / 100f
            canvas.drawRoundRect(RectF(lx, by, lx + (if (fw < bh) bh else fw), by + bh), bh / 2f, bh / 2f, paint)
        }

        // contacts
        val cy = h - m - 18 * d
        paint.color = 0xFF37474F.toInt()
        canvas.drawRect(lx, cy, lr, h - m, paint)
        paint.color = 0xFFFFC107.toInt()
        var cx = lx + 4 * d
        while (cx < lr - 6 * d) {
            canvas.drawRect(cx, cy + 3 * d, cx + 3 * d, h - m - 3 * d, paint)
            cx += 7 * d
        }
    }
}
