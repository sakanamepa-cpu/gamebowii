package com.gamebowii.probe

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.Variable
import java.io.File

/**
 * Built-in player: runs the dumped ROM with an embedded libretro core
 * (Gambatte for GB/GBC, mGBA for GBA) and loads the dumped save into it.
 * On exit the current SRAM is written to a file and returned to MainActivity.
 */
class PlayActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        const val EXTRA_SAV = "sav"
        const val EXTRA_GBA = "gba"
        const val EXTRA_TITLE = "title"
        const val PLAYED_SAVE = "played.sav"
    }

    private lateinit var retro: GLRetroView
    private var isGba = false
    private var leaving = false
    private var failed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rom = intent.getStringExtra(EXTRA_ROM) ?: ""
        val sav = intent.getStringExtra(EXTRA_SAV) ?: ""
        isGba = intent.getBooleanExtra(EXTRA_GBA, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        setContentView(root)

        val data = GLRetroViewData(this)
        data.coreFilePath = applicationInfo.nativeLibraryDir + "/" +
            (if (isGba) "libmgba_libretro_android.so" else "libgambatte_libretro_android.so")
        data.gameFilePath = rom
        data.systemDirectory = filesDir.absolutePath
        val saves = File(cacheDir, "core-saves")
        saves.deleteRecursively()
        saves.mkdirs()
        data.savesDirectory = saves.absolutePath
        if (sav.isNotEmpty()) {
            try {
                data.saveRAMState = File(sav).readBytes()
            } catch (e: Exception) {
            }
        }
        if (!isGba) {
            data.variables = arrayOf(Variable("gambatte_gb_colorization", "auto"))
        }
        data.shader = ShaderConfig.Default
        data.rumbleEventsEnabled = false

        retro = GLRetroView(this, data)
        lifecycle.addObserver(retro)

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        val lpRetro = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        column.addView(retro, lpRetro)
        column.addView(buildControls(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)))
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val exit = TextView(this)
        exit.text = "✕ Έξοδος"
        exit.setTextColor(0xFFFFFFFF.toInt())
        exit.textSize = 14f
        exit.setPadding(dp(14), dp(8), dp(14), dp(8))
        exit.setBackgroundColor(0x88000000.toInt())
        exit.setOnClickListener { finishWithSave() }
        val lpExit = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpExit.gravity = Gravity.TOP or Gravity.END
        lpExit.setMargins(0, dp(28), dp(8), 0)
        root.addView(exit, lpExit)
    }

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    // --------------------------------------------------------- controls

    private fun key(action: Int, code: Int) {
        try {
            retro.sendKeyEvent(action, code)
        } catch (e: Exception) {
        }
    }

    private fun buildControls(): View {
        val f = FrameLayout(this)
        f.setBackgroundColor(0xFF10151B.toInt())

        val dpad = DPadView(this) { code, down ->
            key(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code)
        }
        val lpD = FrameLayout.LayoutParams(dp(170), dp(170))
        lpD.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        lpD.setMargins(dp(14), dp(20), 0, 0)
        f.addView(dpad, lpD)

        fun round(label: String, code: Int, size: Int, gx: Int, ml: Int, mt: Int, mr: Int) {
            val b = RoundButton(this, label, true) { down ->
                key(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code)
            }
            val lp = FrameLayout.LayoutParams(dp(size), dp(size))
            lp.gravity = gx or Gravity.TOP
            lp.setMargins(dp(ml), dp(mt), dp(mr), 0)
            f.addView(b, lp)
        }
        round("A", KeyEvent.KEYCODE_BUTTON_A, 76, Gravity.END, 0, 62, 14)
        round("B", KeyEvent.KEYCODE_BUTTON_B, 76, Gravity.END, 0, 104, 100)

        fun pill(label: String, code: Int, mlOffset: Int, gx: Int) {
            val b = RoundButton(this, label, false) { down ->
                key(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code)
            }
            val lp = FrameLayout.LayoutParams(dp(84), dp(34))
            lp.gravity = gx or Gravity.BOTTOM
            lp.setMargins(dp(mlOffset), 0, dp(if (gx == Gravity.END) mlOffset else 0), dp(14))
            f.addView(b, lp)
        }
        pill("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT, 96, Gravity.START)
        pill("START", KeyEvent.KEYCODE_BUTTON_START, 96, Gravity.END)

        if (isGba) {
            fun shoulder(label: String, code: Int, gx: Int) {
                val b = RoundButton(this, label, false) { down ->
                    key(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code)
                }
                val lp = FrameLayout.LayoutParams(dp(96), dp(36))
                lp.gravity = gx or Gravity.TOP
                lp.setMargins(dp(14), dp(8), dp(14), 0)
                f.addView(b, lp)
            }
            shoulder("L", KeyEvent.KEYCODE_BUTTON_L1, Gravity.START)
            shoulder("R", KeyEvent.KEYCODE_BUTTON_R1, Gravity.END)
        }
        return f
    }

    // ---------------------------------------------- hardware controllers

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) finishWithSave()
            return true
        }
        if (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN ||
            code == KeyEvent.KEYCODE_VOLUME_MUTE || code == KeyEvent.KEYCODE_POWER) {
            return super.dispatchKeyEvent(event)
        }
        key(event.action, code)
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event != null) {
            try {
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD,
                    event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y))
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT,
                    event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))
            } catch (e: Exception) {
            }
        }
        return super.onGenericMotionEvent(event)
    }

    // ------------------------------------------------------------ saving

    private fun writeSram() {
        if (failed) return
        try {
            val b = retro.serializeSRAM()
            if (b.isNotEmpty()) {
                File(getExternalFilesDir(null), PLAYED_SAVE).writeBytes(b)
            }
        } catch (e: Exception) {
        }
    }

    private fun finishWithSave() {
        if (leaving) return
        leaving = true
        writeSram()
        setResult(RESULT_OK, Intent())
        finish()
    }

    override fun onPause() {
        // Must run before super.onPause(): afterwards the emulation thread is paused.
        if (!leaving) writeSram()
        super.onPause()
    }
}

// ---------------------------------------------------------------- views

private class RoundButton(
    context: Context,
    private val label: String,
    private val circle: Boolean,
    private val onChange: (Boolean) -> Unit
) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var down = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (down) 0xFF7E57C2.toInt() else 0xFF3A4654.toInt()
        if (circle) c.drawCircle(w / 2, h / 2, minOf(w, h) / 2 - 2f, p)
        else c.drawRoundRect(RectF(2f, 2f, w - 2f, h - 2f), h / 2, h / 2, p)
        p.color = 0xFFFFFFFF.toInt()
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = if (circle) h * 0.38f else h * 0.38f
        c.drawText(label, w / 2, h / 2 + p.textSize * 0.35f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { if (!down) { down = true; onChange(true); invalidate() } }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (down) { down = false; onChange(false); invalidate() } }
        }
        return true
    }
}

private class DPadView(context: Context, private val onChange: (Int, Boolean) -> Unit) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var up = false
    private var dn = false
    private var lf = false
    private var rt = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = w / 3f
        fun arm(r: RectF, on: Boolean) {
            p.color = if (on) 0xFF7E57C2.toInt() else 0xFF3A4654.toInt()
            c.drawRoundRect(r, 12f, 12f, p)
        }
        p.style = Paint.Style.FILL
        arm(RectF(t, 0f, 2 * t, t + 4f), up)
        arm(RectF(t, 2 * t - 4f, 2 * t, h), dn)
        arm(RectF(0f, t, t + 4f, 2 * t), lf)
        arm(RectF(2 * t - 4f, t, w, 2 * t), rt)
        p.color = 0xFF3A4654.toInt()
        c.drawRect(RectF(t, t, 2 * t, 2 * t), p)
    }

    private fun set(code: Int, now: Boolean, was: Boolean): Boolean {
        if (now != was) onChange(code, now)
        return now
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val dx = e.x - width / 2f
                val dy = e.y - height / 2f
                val dead = width * 0.14f
                up = set(KeyEvent.KEYCODE_DPAD_UP, dy < -dead, up)
                dn = set(KeyEvent.KEYCODE_DPAD_DOWN, dy > dead, dn)
                lf = set(KeyEvent.KEYCODE_DPAD_LEFT, dx < -dead, lf)
                rt = set(KeyEvent.KEYCODE_DPAD_RIGHT, dx > dead, rt)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                up = set(KeyEvent.KEYCODE_DPAD_UP, false, up)
                dn = set(KeyEvent.KEYCODE_DPAD_DOWN, false, dn)
                lf = set(KeyEvent.KEYCODE_DPAD_LEFT, false, lf)
                rt = set(KeyEvent.KEYCODE_DPAD_RIGHT, false, rt)
            }
        }
        invalidate()
        return true
    }
}
