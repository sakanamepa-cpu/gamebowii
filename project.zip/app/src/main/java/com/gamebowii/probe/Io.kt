package com.gamebowii.probe

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import com.hoho.android.usbserial.driver.UsbSerialPort
import java.io.IOException

/** Minimal byte pipe to the GBFlash. */
interface SerialIo {
    /** Returns the number of bytes read, 0 on timeout. */
    fun read(dest: ByteArray, timeoutMs: Int): Int
    fun write(src: ByteArray, timeoutMs: Int)
    fun close()
}

/** Talks to the bulk endpoints directly, without any CH340 control requests. */
class RawIo(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val epIn: UsbEndpoint,
    private val epOut: UsbEndpoint
) : SerialIo {
    override fun read(dest: ByteArray, timeoutMs: Int): Int {
        // Read at most one USB packet per call. A transfer that is larger than the
        // data sent, and that ends exactly on a packet boundary, would otherwise wait
        // for a short packet until it times out and the data would be lost.
        val len = if (dest.size < epIn.maxPacketSize) dest.size else epIn.maxPacketSize
        val n = conn.bulkTransfer(epIn, dest, len, timeoutMs)
        return if (n < 0) 0 else n
    }

    override fun write(src: ByteArray, timeoutMs: Int) {
        val n = conn.bulkTransfer(epOut, src, src.size, timeoutMs)
        if (n < 0) throw IOException("bulk write failed ($n)")
    }

    override fun close() {
        try {
            conn.releaseInterface(iface)
        } catch (e: Exception) {
        }
        conn.close()
    }
}

/** Uses the usb-serial-for-android driver (does the CH340 init sequence). */
class LibIo(private val port: UsbSerialPort) : SerialIo {
    override fun read(dest: ByteArray, timeoutMs: Int): Int = port.read(dest, timeoutMs)

    override fun write(src: ByteArray, timeoutMs: Int) {
        port.write(src, timeoutMs)
    }

    override fun close() {
        try {
            port.close()
        } catch (e: Exception) {
        }
    }
}
