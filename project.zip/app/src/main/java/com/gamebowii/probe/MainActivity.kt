package com.gamebowii.probe

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.File

/**
 * GameBoWii 0.4
 *
 * Read-only tests of the GBFlash:
 *  - Probe: QUERY_FW_INFO only
 *  - Header GB/GBC and Header GBA: powers the cartridge and reads the first
 *    0x180 bytes of ROM (the header). No save or write commands exist here.
 */
class MainActivity : Activity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.gamebowii.probe.USB_PERMISSION"
        private const val VID_CH340 = 0x1A86
    }

    private val LOGO_BYTES = intArrayOf(0xCE,0xED,0x66,0x66,0xCC,0x0D,0x00,0x0B,0x03,0x73,0x00,0x83,0x00,0x0C,0x00,0x0D,0x00,0x08,0x11,0x1F,0x88,0x89,0x00,0x0E,0xDC,0xCC,0x6E,0xE6,0xDD,0xDD,0xD9,0x99,0xBB,0xBB,0x67,0x63,0x6E,0x0E,0xEC,0xCC,0xDD,0xDC,0x99,0x9F,0xBB,0xB9,0x33,0x3E).map { it.toByte() }.toByteArray()

    private enum class Job { PROBE_RAW, HEADER_GB, HEADER_GBA, PROBE_LIB, DUMP_GB }

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var usbManager: UsbManager
    private var pendingJob: Job? = null

    @Volatile
    private var running = false

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val job = pendingJob
            if (granted && job != null) startJob(job) else log("USB permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF101418.toInt())
        root.setPadding(48, 32, 48, 32)

        val title = TextView(this)
        title.text = "GameBoWii 0.4 - GBFlash (read-only dump)\n" +
            "Unplug the GBFlash before inserting or removing a cartridge."
        title.textSize = 22f
        title.setTextColor(Color.WHITE)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val b1 = makeButton("Probe", Job.PROBE_RAW)
        val b5 = makeButton("Dump ROM+save GB/GBC", Job.DUMP_GB)
        val b2 = makeButton("Header GB/GBC", Job.HEADER_GB)
        val b3 = makeButton("Header GBA", Job.HEADER_GBA)
        val b4 = makeButton("Probe (lib)", Job.PROBE_LIB)
        buttons.addView(b1)
        buttons.addView(b5)
        buttons.addView(b2)
        buttons.addView(b3)
        buttons.addView(b4)
        val buttonsScroll = HorizontalScrollView(this)
        buttonsScroll.addView(buttons)

        scroll = ScrollView(this)
        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 18f
        logView.setTextColor(0xFFB8F3B8.toInt())
        scroll.addView(logView)

        root.addView(title)
        root.addView(buttonsScroll)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        b1.requestFocus()

        ContextCompat.registerReceiver(
            this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        log("Ready. 'Probe' = identify the GBFlash (no cartridge needed).")
        log("Log file: ${File(getExternalFilesDir(null), "probe_log.txt").absolutePath}")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(permissionReceiver)
        } catch (e: Exception) {
        }
    }

    private fun makeButton(label: String, job: Job): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { startJob(job) }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        try {
            File(getExternalFilesDir(null), "probe_log.txt").appendText(msg + "\n")
        } catch (e: Exception) {
        }
    }

    private fun startJob(job: Job) {
        if (running) {
            log("Already running.")
            return
        }
        val device = usbManager.deviceList.values.firstOrNull { it.vendorId == VID_CH340 }
        if (device == null) {
            log("No 1A86 (CH340) device found. USB devices seen: ${usbManager.deviceList.size}")
            for (d in usbManager.deviceList.values) {
                log(String.format("  %04X:%04X", d.vendorId, d.productId))
            }
            return
        }
        if (!usbManager.hasPermission(device)) {
            pendingJob = job
            log("Requesting USB permission - accept the dialog on the TV.")
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), flags
            )
            usbManager.requestPermission(device, pi)
            return
        }
        running = true
        Thread {
            try {
                runJob(job, device)
            } catch (e: Exception) {
                log("ERROR: $e")
            } finally {
                running = false
            }
        }.start()
    }

    private fun runJob(job: Job, device: UsbDevice) {
        log("")
        log("--- $job ---")
        val io: SerialIo = (if (job == Job.PROBE_LIB) openLib(device) else openRaw(device)) ?: return
        try {
            val gb = GbFlash(io) { s -> log(s) }
            when (job) {
                Job.PROBE_RAW, Job.PROBE_LIB -> {
                    if (gb.queryFw()) log("RESULT: PASS - GBFlash answered QUERY_FW_INFO.")
                }
                Job.HEADER_GB -> readHeader(gb, true)
                Job.HEADER_GBA -> readHeader(gb, false)
                Job.DUMP_GB -> dumpCart(gb)
            }
        } finally {
            io.close()
            log("Done.")
        }
    }

    private fun readHeader(gb: GbFlash, dmg: Boolean) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(dmg)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(dmg)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            try {
                File(getExternalFilesDir(null), "header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            val from = if (dmg) 0x100 else 0xA0
            val count = if (dmg) 0x50 else 0x20
            var off = from
            while (off < from + count) {
                log(String.format("%03X: ", off) + hexLine(h, off, 16))
                off += 16
            }
            val lines = if (dmg) describeGbHeader(h) else describeGbaHeader(h)
            for (l in lines) log(l)
            log("RESULT: header read OK.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }


    private fun dumpCart(gb: GbFlash) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(true)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(true)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            for (l in describeGbHeader(h)) log(l)
            var logoOk = true
            for (i in 0 until 48) if (h[0x104 + i] != LOGO_BYTES[i]) logoOk = false
            if (!logoOk) {
                log("RESULT: no valid GB cartridge detected - aborting.")
                return
            }
            var name = ""
            for (i in 0x134..0x143) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "game"
            val cgb = (h[0x143].toInt() and 0xFF)
            val ext = if (cgb == 0x80 || cgb == 0xC0) "gbc" else "gb"
            var lastPct = -10
            val rom = gb.dumpRom(h) { pct ->
                if (pct >= lastPct + 10) {
                    lastPct = pct
                    log("ROM $pct%")
                }
            }
            if (rom == null) {
                log("RESULT: ROM dump FAILED.")
                return
            }
            var sum = 0
            for (i in rom.indices) if (i != 0x14E && i != 0x14F) sum += rom[i].toInt() and 0xFF
            sum = sum and 0xFFFF
            val stored = ((rom[0x14E].toInt() and 0xFF) shl 8) or (rom[0x14F].toInt() and 0xFF)
            val dir = getExternalFilesDir(null)
            val romFile = File(dir, "$name.$ext")
            romFile.writeBytes(rom)
            log("ROM saved: ${romFile.absolutePath} (${rom.size} bytes)")
            log(String.format("Global checksum: stored %04X, computed %04X -> %s", stored, sum,
                if (stored == sum) "OK, ROM is verified" else "MISMATCH (retry; a few games have bad checksums)"))
            lastPct = -10
            val sav = gb.dumpSave(h) { pct ->
                if (pct >= lastPct + 50) {
                    lastPct = pct
                    log("Save read $pct%")
                }
            }
            if (sav == null) {
                log("RESULT: save read FAILED (ROM file is still saved).")
            } else if (sav.isNotEmpty()) {
                val savFile = File(dir, "$name.sav")
                savFile.writeBytes(sav)
                log("Save saved: ${savFile.absolutePath} (${sav.size} bytes, two reads identical)")
            }
            log("RESULT: dump finished.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun openRaw(device: UsbDevice): SerialIo? {
        var iface: UsbInterface? = null
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            var ein: UsbEndpoint? = null
            var eout: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) ein = ep else eout = ep
                }
            }
            if (ein != null && eout != null) {
                iface = itf
                inEp = ein
                outEp = eout
                break
            }
        }
        if (iface == null || inEp == null || outEp == null) {
            log("No bulk IN/OUT endpoints found.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        if (!conn.claimInterface(iface, true)) {
            log("claimInterface failed.")
            conn.close()
            return null
        }
        log(
            String.format(
                "Raw USB: interface %d, IN=%02X OUT=%02X, maxpkt=%d",
                iface.id, inEp.address, outEp.address, inEp.maxPacketSize
            )
        )
        return RawIo(conn, iface, inEp, outEp)
    }

    private fun openLib(device: UsbDevice): SerialIo? {
        val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
        if (driver == null) {
            log("No usb-serial driver for this device.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        val port = driver.ports[0]
        port.open(conn)
        try {
            port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            log("setParameters: $e")
        }
        return LibIo(port)
    }
}
