package com.gamebowii.probe

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * GB CartPlay 0.9.4
 *
 * Read-only tests of the GBFlash:
 *  - Probe: QUERY_FW_INFO only
 *  - Header GB/GBC and Header GBA: powers the cartridge and reads the first
 *    0x180 bytes of ROM (the header). No save or write commands exist here.
 */
class MainActivity : Activity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.gamebowii.probe.USB_PERMISSION"
        private const val VID_CH340 = 0x1A86
        private const val REQ_PICK_SAVE = 77
        private const val GBA_PACKAGE_GUESS = "it.dbtecno.pizzaboygbapro"
        private const val EMU_PACKAGE = "it.dbtecno.pizzaboypro"
        private const val EMU_ACTIVITY = "it.dbtecno.pizzaboypro.MainActivity"
    }

    private val LOGO_BYTES = intArrayOf(0xCE,0xED,0x66,0x66,0xCC,0x0D,0x00,0x0B,0x03,0x73,0x00,0x83,0x00,0x0C,0x00,0x0D,0x00,0x08,0x11,0x1F,0x88,0x89,0x00,0x0E,0xDC,0xCC,0x6E,0xE6,0xDD,0xDD,0xD9,0x99,0xBB,0xBB,0x67,0x63,0x6E,0x0E,0xEC,0xCC,0xDD,0xDC,0x99,0x9F,0xBB,0xB9,0x33,0x3E).map { it.toByte() }.toByteArray()

    private enum class Job { PROBE_RAW, HEADER_GB, HEADER_GBA, PROBE_LIB, DUMP_GB, DUMP_GBA, WRITE_SAVE }

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var usbManager: UsbManager
    private var pendingJob: Job? = null

    @Volatile
    private var running = false

    private lateinit var cartView: CartridgeView
    private lateinit var gameTitle: TextView
    private lateinit var chipRow1: LinearLayout
    private lateinit var chipRow2: LinearLayout
    private lateinit var phaseText: TextView
    private lateinit var banner: TextView
    private lateinit var details: LinearLayout
    private val actionButtons = ArrayList<Button>()
    private var detailsOpen = false

    private var lastPubUri: Uri? = null
    private var lastRomUri: Uri? = null
    private var lastPubName: String? = null
    private var awaitingReturn = false
    private var lastRomPath: String? = null
    private var pendingSave: ByteArray? = null

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val job = pendingJob
            if (granted && job != null) startJob(job) else log("USB permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        // Needed to hand a file:// path to the emulator app.
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())

        val outer = ScrollView(this)
        outer.setBackgroundColor(0xFF101418.toInt())
        outer.isFillViewport = true
        scroll = outer

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))

        val title = TextView(this)
        title.text = "GB CartPlay"
        title.textSize = 28f
        title.setTypeface(Typeface.DEFAULT_BOLD)
        title.setTextColor(Color.WHITE)

        val sub = TextView(this)
        sub.text = "Βάλε το cartridge στο GBFlash και σύνδεσέ το στο κινητό.\nΒγάλε το GBFlash πριν βάλεις ή βγάλεις cartridge."
        sub.textSize = 14f
        sub.setTextColor(0xFFB0BEC5.toInt())
        sub.setPadding(0, dp(4), 0, dp(16))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = rounded(0xFF1B2128.toInt(), 20)
        card.setPadding(dp(16), dp(20), dp(16), dp(16))

        cartView = CartridgeView(this)
        gameTitle = TextView(this)
        gameTitle.text = "Κανένα cartridge ακόμα"
        gameTitle.textSize = 20f
        gameTitle.setTypeface(Typeface.DEFAULT_BOLD)
        gameTitle.setTextColor(Color.WHITE)
        gameTitle.gravity = Gravity.CENTER
        gameTitle.setPadding(0, dp(12), 0, dp(8))

        chipRow1 = LinearLayout(this)
        chipRow1.orientation = LinearLayout.HORIZONTAL
        chipRow1.gravity = Gravity.CENTER
        chipRow2 = LinearLayout(this)
        chipRow2.orientation = LinearLayout.HORIZONTAL
        chipRow2.gravity = Gravity.CENTER

        phaseText = TextView(this)
        phaseText.textSize = 15f
        phaseText.setTextColor(0xFF90A4AE.toInt())
        phaseText.gravity = Gravity.CENTER
        phaseText.setPadding(0, dp(12), 0, 0)

        banner = TextView(this)
        banner.textSize = 16f
        banner.setTypeface(Typeface.DEFAULT_BOLD)
        banner.setTextColor(Color.WHITE)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(14), dp(12), dp(14), dp(12))
        banner.visibility = View.GONE
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.setMargins(0, dp(14), 0, 0)
        banner.layoutParams = bl

        card.addView(cartView)
        card.addView(gameTitle)
        card.addView(chipRow1)
        card.addView(chipRow2)
        card.addView(phaseText)
        card.addView(banner)
        val cardLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cardLp.setMargins(0, 0, 0, dp(16))
        card.layoutParams = cardLp

        val playBtn = bigButton("Διάβασε cartridge και παίξε", 0xFF2E7D32.toInt(), true) { startJob(Job.DUMP_GB) }
        val playGbaBtn = bigButton("Διάβασε GBA cartridge και παίξε", 0xFF1565C0.toInt(), true) { startJob(Job.DUMP_GBA) }
        val writeBtn = bigButton("Γράψε το save στο cartridge", 0xFFB26A00.toInt(), true) { pickSaveFile() }
        val againBtn = bigButton("Άνοιγμα παιχνιδιού (χωρίς νέο dump)", 0xFF455A64.toInt(), true) { launchEmulator(true) }

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(makeButton("Probe", Job.PROBE_RAW))
        tools.addView(makeButton("Header GB/GBC", Job.HEADER_GB))
        tools.addView(makeButton("Header GBA", Job.HEADER_GBA))
        tools.addView(makeButton("Probe (lib)", Job.PROBE_LIB))
        tools.addView(makeActionButton("Open ROM (content)") { launchEmulator(false) })
        val toolsScroll = HorizontalScrollView(this)
        toolsScroll.addView(tools)

        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 13f
        logView.setTextColor(0xFFB8F3B8.toInt())
        logView.setPadding(0, dp(8), 0, 0)

        details = LinearLayout(this)
        details.orientation = LinearLayout.VERTICAL
        details.addView(toolsScroll)
        details.addView(logView)
        details.visibility = View.GONE

        val detailsBtn = bigButton("Λεπτομέρειες και εργαλεία", 0xFF263238.toInt(), false) {
            detailsOpen = !detailsOpen
            details.visibility = if (detailsOpen) View.VISIBLE else View.GONE
        }

        root.addView(title)
        root.addView(sub)
        root.addView(card)
        root.addView(playBtn)
        root.addView(playGbaBtn)
        root.addView(writeBtn)
        root.addView(againBtn)
        root.addView(detailsBtn)
        root.addView(details)
        outer.addView(root)
        setContentView(outer)
        playBtn.requestFocus()
        if (Build.VERSION.SDK_INT in 23..28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        ContextCompat.registerReceiver(
            this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        log("Έτοιμο.")
        log("Log file: ${File(getExternalFilesDir(null), "probe_log.txt").absolutePath}")
    }

    override fun onResume() {
        super.onResume()
        if (awaitingReturn && !running) {
            awaitingReturn = false
            AlertDialog.Builder(this)
                .setTitle("Τέλος παιχνιδιού;")
                .setMessage("Θες να γράψω το save του παιχνιδιού πίσω στο cartridge; Θα σε ρωτήσω ξανά πριν γραφτεί οτιδήποτε.")
                .setPositiveButton("Ναι, διάλεξε το save") { _, _ -> pickSaveFile() }
                .setNegativeButton("Όχι τώρα", null)
                .show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(permissionReceiver)
        } catch (e: Exception) {
        }
    }

    private fun makeButton(label: String, job: Job): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { startJob(job) }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radiusDp * resources.displayMetrics.density
        return g
    }

    private fun bigButton(label: String, color: Int, isAction: Boolean, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.isAllCaps = false
        b.textSize = 17f
        b.setTextColor(Color.WHITE)
        b.background = rounded(color, 14)
        b.setPadding(dp(16), dp(16), dp(16), dp(16))
        b.setOnFocusChangeListener { v, hasFocus ->
            v.alpha = if (hasFocus) 1.0f else 0.9f
        }
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, dp(10))
        b.layoutParams = lp
        if (isAction) actionButtons.add(b)
        return b
    }

    private fun chip(text: String, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.background = rounded(color, 12)
        t.setPadding(dp(10), dp(4), dp(10), dp(4))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        t.layoutParams = lp
        return t
    }

    // ---------------------------------------------------- friendly status UI

    private fun uiReset() {
        runOnUiThread {
            cartView.title = ""
            cartView.progress = 0
            gameTitle.text = "Κανένα cartridge ακόμα"
            chipRow1.removeAllViews()
            chipRow2.removeAllViews()
            phaseText.text = ""
            banner.visibility = View.GONE
        }
    }

    private fun uiPhase(text: String) {
        runOnUiThread { phaseText.text = text }
    }

    private fun uiProgress(pct: Int) {
        runOnUiThread { cartView.progress = pct }
    }

    private fun uiChip(row: Int, text: String, color: Int) {
        runOnUiThread { (if (row == 1) chipRow1 else chipRow2).addView(chip(text, color)) }
    }

    private fun uiBanner(kind: Int, text: String) {
        runOnUiThread {
            banner.text = text
            banner.background = rounded(
                when (kind) {
                    1 -> 0xFF1B5E20.toInt()
                    2 -> 0xFFB71C1C.toInt()
                    else -> 0xFF37474F.toInt()
                }, 14
            )
            banner.visibility = View.VISIBLE
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            for (b in actionButtons) {
                b.isEnabled = !busy
                b.alpha = if (busy) 0.4f else 1.0f
            }
        }
    }

    private fun titleOf(h: ByteArray): String {
        val cgb = h[0x143].toInt() and 0xFF
        val len = if (cgb == 0x80 || cgb == 0xC0) 11 else 15
        val sb = StringBuilder()
        for (i in 0x134 until 0x134 + len) {
            val c = h[i].toInt() and 0xFF
            if (c == 0) break
            sb.append(if (c in 32..126) c.toChar() else '?')
        }
        return sb.toString().trim()
    }

    private fun sizeText(bytes: Int): String =
        if (bytes >= 1024 * 1024) (bytes / (1024 * 1024)).toString() + " MB" else (bytes / 1024).toString() + " KB"

    private fun uiGame(h: ByteArray) {
        val type = h[0x147].toInt() and 0xFF
        val code = h[0x148].toInt() and 0xFF
        val romBytes = if (code <= 8) 0x8000 shl code else 0
        val sav = saveSizeFor(h)
        val name = titleOf(h)
        runOnUiThread {
            cartView.title = name
            gameTitle.text = name
            chipRow1.removeAllViews()
            chipRow2.removeAllViews()
            chipRow1.addView(chip(cartTypeName(type), 0xFF455A64.toInt()))
            if (romBytes > 0) chipRow2.addView(chip("ROM " + sizeText(romBytes), 0xFF455A64.toInt()))
            chipRow2.addView(
                chip(if (sav > 0) "Save " + sizeText(sav) else "Χωρίς save", 0xFF455A64.toInt())
            )
        }
    }

    private fun friendly(msg: String): Pair<Int, String>? {
        return when {
            msg.startsWith("RESULT: dump finished") -> Pair(1, "Το παιχνίδι είναι έτοιμο! Ανοίγω το Pizza Boy…")
            msg.startsWith("RESULT: save written and verified") -> Pair(1, "Το save γράφτηκε στο cartridge και ελέγχθηκε ✓")
            msg.startsWith("RESULT: header read FAILED") -> Pair(2, "Δεν μπόρεσα να διαβάσω το cartridge. Βεβαιώσου ότι είναι σωστά βαλμένο και ξαναδοκίμασε.")
            msg.startsWith("RESULT: no valid GB") -> Pair(2, "Δεν βρέθηκε cartridge Game Boy στο GBFlash.")
            msg.startsWith("RESULT: ROM dump FAILED") -> Pair(2, "Η ανάγνωση του παιχνιδιού απέτυχε. Δοκίμασε ξανά.")
            msg.startsWith("RESULT: save read FAILED") -> Pair(2, "Το παιχνίδι διαβάστηκε, αλλά το save όχι.")
            msg.startsWith("RESULT: this is not the cartridge") -> Pair(2, "Αυτό δεν είναι το cartridge που διάβασες. Δεν γράφτηκε τίποτα.")
            msg.startsWith("RESULT: could not") -> Pair(2, "Δεν μπόρεσα να κάνω αντίγραφο ασφαλείας, γι' αυτό δεν έγραψα τίποτα.")
            msg.startsWith("RESULT: save write FAILED") -> Pair(2, "Η εγγραφή απέτυχε. Το προηγούμενο save υπάρχει στο backup.")
            msg.startsWith("RESULT:") -> Pair(2, msg.removePrefix("RESULT: "))
            msg.startsWith("No 1A86") -> Pair(2, "Δεν βρίσκω το GBFlash. Σύνδεσέ το στο κινητό (OTG).")
            msg.startsWith("USB permission denied") -> Pair(2, "Χρειάζεται άδεια USB για το GBFlash.")
            msg.startsWith("ERROR:") -> Pair(2, "Κάτι πήγε στραβά: " + msg.removePrefix("ERROR: "))
            msg.startsWith("Cancelled") -> Pair(0, "Ακυρώθηκε. Δεν γράφτηκε τίποτα.")
            msg.startsWith("Could not power") -> Pair(2, "Δεν μπόρεσα να ενεργοποιήσω την υποδοχή του cartridge.")
            msg.startsWith("No ROM has been dumped") -> Pair(2, "Δεν υπάρχει ακόμα παιχνίδι. Διάβασε πρώτα ένα cartridge.")
            msg.startsWith("Dump the cartridge first") -> Pair(2, "Διάβασε πρώτα το cartridge.")
            msg.startsWith("The save file is") -> Pair(2, "Το αρχείο save δεν ταιριάζει σε αυτό το παιχνίδι. Δεν γράφτηκε τίποτα.")
            msg.startsWith("No save named") -> Pair(2, "Δεν βρήκα save με το όνομα αυτού του παιχνιδιού στο zip. Δεν γράφτηκε τίποτα.")
            else -> null
        }
    }

    private fun makeActionButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            if (detailsOpen) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        val f = friendly(msg)
        if (f != null) uiBanner(f.first, f.second)
        try {
            File(getExternalFilesDir(null), "probe_log.txt").appendText(msg + "\n")
        } catch (e: Exception) {
        }
    }

    private fun startJob(job: Job) {
        if (running) {
            log("Already running.")
            return
        }
        val device = usbManager.deviceList.values.firstOrNull { it.vendorId == VID_CH340 }
        if (device == null) {
            log("No 1A86 (CH340) device found. USB devices seen: ${usbManager.deviceList.size}")
            for (d in usbManager.deviceList.values) {
                log(String.format("  %04X:%04X", d.vendorId, d.productId))
            }
            return
        }
        if (!usbManager.hasPermission(device)) {
            pendingJob = job
            log("Requesting USB permission - accept the dialog on the TV.")
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), flags
            )
            usbManager.requestPermission(device, pi)
            return
        }
        running = true
        setBusy(true)
        if (job == Job.DUMP_GB || job == Job.DUMP_GBA) uiReset()
        if (job == Job.DUMP_GB || job == Job.DUMP_GBA || job == Job.WRITE_SAVE) {
            runOnUiThread { banner.visibility = View.GONE }
            uiPhase("Συνδέομαι με το GBFlash…")
        }
        Thread {
            try {
                runJob(job, device)
            } catch (e: Exception) {
                log("ERROR: $e")
            } finally {
                running = false
                setBusy(false)
            }
        }.start()
    }

    private fun runJob(job: Job, device: UsbDevice) {
        log("")
        log("--- $job ---")
        val io: SerialIo = (if (job == Job.PROBE_LIB) openLib(device) else openRaw(device)) ?: return
        try {
            val gb = GbFlash(io) { s -> log(s) }
            when (job) {
                Job.PROBE_RAW, Job.PROBE_LIB -> {
                    if (gb.queryFw()) log("RESULT: PASS - GBFlash answered QUERY_FW_INFO.")
                }
                Job.HEADER_GB -> readHeader(gb, true)
                Job.HEADER_GBA -> readHeader(gb, false)
                Job.DUMP_GB -> dumpCart(gb)
                Job.DUMP_GBA -> dumpGba(gb)
                Job.WRITE_SAVE -> writeSaveJob(gb)
            }
        } finally {
            io.close()
            log("Done.")
        }
    }

    private fun readHeader(gb: GbFlash, dmg: Boolean) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(dmg)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(dmg)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            try {
                File(getExternalFilesDir(null), "header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            val from = if (dmg) 0x100 else 0xA0
            val count = if (dmg) 0x50 else 0x20
            var off = from
            while (off < from + count) {
                log(String.format("%03X: ", off) + hexLine(h, off, 16))
                off += 16
            }
            val lines = if (dmg) describeGbHeader(h) else describeGbaHeader(h)
            for (l in lines) log(l)
            log("RESULT: header read OK.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }


    /** Copies a dump into the visible folder Download/GameBoWii. Returns a description or null. */
    private fun publishToDownloads(fileName: String, data: ByteArray): String? {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val rel = "Download/GameBoWii"
                var found: Uri? = null
                contentResolver.query(
                    collection, arrayOf(MediaStore.Downloads._ID),
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    arrayOf(fileName, "$rel/"), null
                )?.use { c ->
                    if (c.moveToFirst()) found = ContentUris.withAppendedId(collection, c.getLong(0))
                }
                var written = false
                val existing = found
                if (existing != null) {
                    try {
                        contentResolver.openOutputStream(existing, "wt")?.use { it.write(data) }
                        written = true
                    } catch (e: Exception) {
                        written = false
                    }
                }
                if (!written) {
                    val values = ContentValues()
                    val dot = fileName.lastIndexOf('.')
                    val stamp = SimpleDateFormat("yyMMdd_HHmmss", Locale.US).format(Date())
                    val safeName = if (existing != null || found != null)
                        (if (dot > 0) fileName.substring(0, dot) + "_" + stamp + fileName.substring(dot) else fileName + "_" + stamp)
                    else fileName
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    values.put(MediaStore.Downloads.RELATIVE_PATH, rel)
                    val uri = contentResolver.insert(collection, values) ?: return null
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(data) }
                    found = uri
                }
                lastPubUri = found
                var actual = fileName
                try {
                    val fu = found
                    if (fu != null) contentResolver.query(fu, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) actual = c.getString(0) ?: fileName
                    }
                } catch (e: Exception) {
                }
                lastPubName = actual
                return "Download/GameBoWii/$actual"
            } else {
                if (Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    log("No storage permission - accept it and dump again to get the copy in Download/GameBoWii.")
                    return null
                }
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "GameBoWii")
                dir.mkdirs()
                File(dir, fileName).writeBytes(data)
                lastPubUri = Uri.fromFile(File(dir, fileName))
                lastPubName = fileName
                return "Download/GameBoWii/$fileName"
            }
        } catch (e: Exception) {
            log("Could not copy $fileName to Download/GameBoWii: $e")
            return null
        }
    }

    private fun dumpCart(gb: GbFlash) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(true)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(true)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            for (l in describeGbHeader(h)) log(l)
            uiGame(h)
            uiPhase("Διαβάζω το παιχνίδι…")
            try {
                File(getExternalFilesDir(null), "last_header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            var logoOk = true
            for (i in 0 until 48) if (h[0x104 + i] != LOGO_BYTES[i]) logoOk = false
            if (!logoOk) {
                log("RESULT: no valid GB cartridge detected - aborting.")
                return
            }
            var name = ""
            for (i in 0x134..0x143) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "game"
            val cgb = (h[0x143].toInt() and 0xFF)
            val ext = if (cgb == 0x80 || cgb == 0xC0) "gbc" else "gb"
            var lastPct = -10
            val rom = gb.dumpRom(h) { pct ->
                uiProgress(pct)
                if (pct >= lastPct + 10) {
                    lastPct = pct
                    log("ROM $pct%")
                }
            }
            if (rom == null) {
                log("RESULT: ROM dump FAILED.")
                return
            }
            var sum = 0
            for (i in rom.indices) if (i != 0x14E && i != 0x14F) sum += rom[i].toInt() and 0xFF
            sum = sum and 0xFFFF
            val stored = ((rom[0x14E].toInt() and 0xFF) shl 8) or (rom[0x14F].toInt() and 0xFF)
            val dir = getExternalFilesDir(null)
            val romFile = File(dir, "$name.$ext")
            romFile.writeBytes(rom)
            log("ROM saved: ${romFile.absolutePath} (${rom.size} bytes)")
            val romPub = publishToDownloads("$name.$ext", rom)
            if (romPub != null) {
                log("ROM copy: $romPub")
                lastRomUri = lastPubUri
                lastRomPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath +
                    "/GameBoWii/" + (lastPubName ?: "$name.$ext")
                try {
                    File(getExternalFilesDir(null), "last_rom_path.txt").writeText(lastRomPath ?: "")
                } catch (e: Exception) {
                }
            }
            log(String.format("Global checksum: stored %04X, computed %04X -> %s", stored, sum,
                if (stored == sum) "OK, ROM is verified" else "MISMATCH (retry; a few games have bad checksums)"))
            uiChip(2, if (stored == sum) "Έλεγχος ROM ✓" else "Έλεγχος ROM ✗", if (stored == sum) 0xFF2E7D32.toInt() else 0xFFB26A00.toInt())
            uiPhase("Διαβάζω το save…")
            uiProgress(0)
            lastPct = -10
            val sav = gb.dumpSave(h) { pct ->
                uiProgress(pct)
                if (pct >= lastPct + 50) {
                    lastPct = pct
                    log("Save read $pct%")
                }
            }
            if (sav == null) {
                log("RESULT: save read FAILED (ROM file is still saved).")
            } else if (sav.isNotEmpty()) {
                val savFile = File(dir, "$name.sav")
                savFile.writeBytes(sav)
                log("Save saved: ${savFile.absolutePath} (${sav.size} bytes, two reads identical)")
                val savPub = publishToDownloads("$name.sav", sav)
                if (savPub != null) log("Save copy: $savPub")
                publishToDownloads("$name.srm", sav)
            }
            uiPhase("Έτοιμο")
            uiProgress(100)
            log("RESULT: dump finished. Opening the emulator...")
            runOnUiThread { launchEmulator(true) }
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun dumpGba(gb: GbFlash) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(false)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(false)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            for (l in describeGbaHeader(h)) log(l)
            if ((h[0xB2].toInt() and 0xFF) != 0x96) {
                log("RESULT: no valid GB cartridge detected (no GBA header) - aborting.")
                return
            }
            var name = ""
            for (i in 0xA0..0xAB) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "gba_game"
            val title = name.replace('_', ' ').trim()
            runOnUiThread {
                cartView.title = title
                gameTitle.text = title
                chipRow1.removeAllViews(); chipRow2.removeAllViews()
                chipRow1.addView(chip("Game Boy Advance", 0xFF455A64.toInt()))
            }
            uiPhase("Μετράω το μέγεθος του παιχνιδιού…")
            val size = gb.detectGbaRomSize(h)
            if (size <= 0) {
                log("RESULT: ROM dump FAILED.")
                return
            }
            log("GBA ROM size detected: $size bytes")
            runOnUiThread { chipRow2.addView(chip("ROM " + sizeText(size), 0xFF455A64.toInt())) }
            uiPhase("Διαβάζω το παιχνίδι…")
            var lastPct = -10
            val rom = gb.dumpGbaRom(size) { pct ->
                uiProgress(pct)
                if (pct >= lastPct + 10) { lastPct = pct; log("ROM $pct%") }
            }
            if (rom == null) {
                log("RESULT: ROM dump FAILED.")
                return
            }
            val dir = getExternalFilesDir(null)
            File(dir, "$name.gba").writeBytes(rom)
            val romPub = publishToDownloads("$name.gba", rom)
            if (romPub != null) {
                log("ROM copy: $romPub")
                lastRomUri = lastPubUri
                lastRomPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath +
                    "/GameBoWii/" + (lastPubName ?: "$name.gba")
                try {
                    File(getExternalFilesDir(null), "last_rom_path.txt").writeText(lastRomPath ?: "")
                } catch (e: Exception) {
                }
            }
            val saveType = gb.detectGbaSave(rom)
            log("GBA save type (guessed from ROM): $saveType")
            uiPhase("Διαβάζω το save…")
            uiProgress(0)
            val sav = gb.dumpGbaSave(saveType) { pct -> uiProgress(pct) }
            if (sav == null) {
                log("RESULT: save read FAILED (ROM file is still saved).")
            } else if (sav.isNotEmpty()) {
                File(dir, "$name.sav").writeBytes(sav)
                log("Save saved: $name.sav (${sav.size} bytes, two reads identical)")
                val savPub = publishToDownloads("$name.sav", sav)
                if (savPub != null) log("Save copy: $savPub")
                publishToDownloads("$name.srm", sav)
                runOnUiThread { chipRow2.addView(chip("Save " + sizeText(sav.size), 0xFF455A64.toInt())) }
            } else {
                runOnUiThread { chipRow2.addView(chip("Χωρίς save", 0xFF455A64.toInt())) }
            }
            uiPhase("Έτοιμο")
            uiProgress(100)
            log("RESULT: dump finished. Opening the emulator...")
            runOnUiThread { launchEmulator(true) }
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun launchEmulator(useFile: Boolean) {
        var path = lastRomPath
        if (path == null) {
            try {
                val f = File(getExternalFilesDir(null), "last_rom_path.txt")
                if (f.exists()) path = f.readText().trim().ifEmpty { null }
            } catch (e: Exception) {
            }
        }
        val cUri = lastRomUri
        val uri: Uri? = if (useFile) (if (path != null) Uri.fromFile(File(path)) else null) else cUri
        if (uri == null) {
            log("No ROM has been dumped yet in this session.")
            return
        }
        val raPkg = listOf("com.retroarch.aarch64", "com.retroarch", "com.retroarch.ra32")
            .firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (raPkg != null && path != null) {
            try {
                val ri = Intent()
                ri.component = ComponentName(raPkg, "com.retroarch.browser.retroactivity.RetroActivityFuture")
                ri.putExtra("ROM", path)
                ri.putExtra("LIBRETRO", "/data/data/$raPkg/cores/mgba_libretro_android.so")
                ri.putExtra("CONFIGFILE", "/storage/emulated/0/Android/data/$raPkg/files/retroarch.cfg")
                ri.putExtra("QUITFOCUS", "")
                ri.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                awaitingReturn = !path.lowercase().endsWith(".gba")
                startActivity(ri)
                log("Opened RetroArch ($raPkg, mGBA core) with $path")
                return
            } catch (e: Exception) {
                log("Could not open RetroArch: $e - trying Pizza Boy.")
            }
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            val isGba = (path ?: "").lowercase().endsWith(".gba")
            if (isGba) {
                val lp = packageManager.getLaunchIntentForPackage(GBA_PACKAGE_GUESS)
                if (lp?.component == null) {
                    log("RESULT: Pizza Boy A Pro not found (package $GBA_PACKAGE_GUESS). Open it manually and load the .gba from Download/GameBoWii.")
                    return
                }
                i.component = lp.component
            } else {
                i.component = ComponentName(EMU_PACKAGE, EMU_ACTIVITY)
            }
            i.data = uri
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            awaitingReturn = !isGba
            startActivity(i)
            log("Opened the emulator with $uri")
        } catch (e: Exception) {
            log("Could not open the emulator: $e")
        }
    }

    private fun pickSaveFile() {
        if ((lastRomPath ?: "").lowercase().endsWith(".gba")) {
            log("RESULT: GBA save write-back is not supported yet. Nothing was written.")
            return
        }
        val hf = File(getExternalFilesDir(null), "last_header.bin")
        if (!hf.exists()) {
            log("Dump the cartridge first (it records which cartridge this is).")
            return
        }
        log("Pick the save file (.sav) or the Pizza Boy export (.zip) to write to the cartridge...")
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, REQ_PICK_SAVE)
        } catch (e: Exception) {
            log("No file picker available on this device: $e")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_SAVE || resultCode != RESULT_OK) return
        val picked: Uri = data?.data ?: return
        val raw: ByteArray = try {
            contentResolver.openInputStream(picked)?.use { it.readBytes() } ?: return
        } catch (e: Exception) {
            log("Could not read the selected file: $e")
            return
        }
        val h = try {
            File(getExternalFilesDir(null), "last_header.bin").readBytes()
        } catch (e: Exception) {
            log("Dump the cartridge first.")
            return
        }
        var bytes: ByteArray = raw
        if (raw.size > 4 && raw[0] == 0x50.toByte() && raw[1] == 0x4B.toByte()) {
            val found = pickSaveFromZip(raw, h)
            if (found == null) return
            bytes = found
        }
        val expected = saveSizeFor(h)
        val title = describeGbHeader(h).firstOrNull { it.startsWith("Title") } ?: ""
        if (expected == 0 || bytes.size != expected) {
            log("The save file is ${bytes.size} bytes but this cartridge needs $expected. Nothing will be written.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Εγγραφή save στο cartridge")
            .setMessage(
                title + "\nΑρχείο: " + (picked.lastPathSegment ?: "?") + "\n\nΘα ΑΝΤΙΚΑΤΑΣΤΑΘΕΙ το save που υπάρχει τώρα στο cartridge με το αρχείο που διάλεξες (" +
                    bytes.size + " bytes).\n\nΠρώτα θα φυλαχθεί αντίγραφο του τωρινού save στο Download/GameBoWii. " +
                    "Μετά την εγγραφή γίνεται έλεγχος. Να συνεχίσω;"
            )
            .setNegativeButton("Ακύρωση") { _, _ -> log("Cancelled. Nothing was written.") }
            .setPositiveButton("Γράψε το save") { _, _ ->
                pendingSave = bytes
                startJob(Job.WRITE_SAVE)
            }
            .show()
    }

    private fun gameName(h: ByteArray): String {
        var name = ""
        for (i in 0x134..0x143) {
            val c = h[i].toInt() and 0xFF
            if (c == 0) break
            name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
        }
        return if (name.isEmpty()) "game" else name
    }

    /** Finds the battery save of the dumped game inside a Pizza Boy "Export to zip" file. */
    private fun pickSaveFromZip(zipBytes: ByteArray, h: ByteArray): ByteArray? {
        val expected = saveSizeFor(h)
        val wanted = gameName(h).lowercase(Locale.US) + ".sav"
        val names = ArrayList<String>()
        val datas = ArrayList<ByteArray>()
        try {
            val zis = ZipInputStream(ByteArrayInputStream(zipBytes))
            var e = zis.nextEntry
            while (e != null) {
                val n = e.name
                val low = n.lowercase(Locale.US)
                if (!e.isDirectory && low.endsWith(".sav") && !low.contains(".bak") && !low.contains("backup")) {
                    val d = zis.readBytes()
                    names.add(n)
                    datas.add(d)
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        } catch (ex: Exception) {
            log("Could not read the zip: $ex")
            return null
        }
        log("Saves found in the zip: " + (if (names.isEmpty()) "none" else names.joinToString(", ")))
        var best = -1
        for (i in names.indices) {
            val base = names[i].substringAfterLast('/').lowercase(Locale.US)
            if (base == wanted && datas[i].size == expected) best = i
        }
        if (best < 0) {
            log("No save named $wanted ($expected bytes) in the zip. Nothing will be written.")
            return null
        }
        log("Using: " + names[best])
        return datas[best]
    }

    private fun writeSaveJob(gb: GbFlash) {
        val data = pendingSave
        pendingSave = null
        if (data == null) {
            log("No save selected.")
            return
        }
        if (!gb.queryFw()) return
        try {
            val saved = try {
                File(getExternalFilesDir(null), "last_header.bin").readBytes()
            } catch (e: Exception) {
                log("Dump the cartridge first.")
                return
            }
            if (!gb.setMode(true)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(true)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED. Nothing written.")
                return
            }
            for (i in 0x134..0x14F) {
                if (h[i] != saved[i]) {
                    log("RESULT: this is not the cartridge that was dumped. Nothing written.")
                    return
                }
            }
            log("Cartridge matches the dump. Backing up the current save...")
            uiGame(h)
            uiPhase("Φυλάσσω αντίγραφο του τωρινού save…")
            val old = gb.dumpSave(h) { }
            if (old == null || old.isEmpty()) {
                log("RESULT: could not back up the current save. Nothing written.")
                return
            }
            var name = ""
            for (i in 0x134..0x143) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "game"
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val backupName = "backup-$name-$stamp.sav"
            try {
                File(getExternalFilesDir(null), backupName).writeBytes(old)
            } catch (e: Exception) {
                log("RESULT: could not store the backup. Nothing written.")
                return
            }
            val pub = publishToDownloads(backupName, old)
            if (pub == null) log("Note: the visible backup copy failed; the backup is in the app folder.")
            else log("Backup saved: $pub")
            log("Writing the save...")
            uiPhase("Γράφω το save στο cartridge…")
            uiProgress(0)
            var last = -25
            val ok = gb.writeSave(h, data) { pct ->
                uiProgress(pct)
                if (pct >= last + 25) {
                    last = pct
                    log("Save write $pct%")
                }
            }
            if (ok) uiPhase("Επαληθεύτηκε")
            if (ok) log("RESULT: save written and verified.")
            else log("RESULT: save write FAILED. Your previous save is in $backupName - write it back with this same button.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun openRaw(device: UsbDevice): SerialIo? {
        var iface: UsbInterface? = null
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            var ein: UsbEndpoint? = null
            var eout: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) ein = ep else eout = ep
                }
            }
            if (ein != null && eout != null) {
                iface = itf
                inEp = ein
                outEp = eout
                break
            }
        }
        if (iface == null || inEp == null || outEp == null) {
            log("No bulk IN/OUT endpoints found.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        if (!conn.claimInterface(iface, true)) {
            log("claimInterface failed.")
            conn.close()
            return null
        }
        log(
            String.format(
                "Raw USB: interface %d, IN=%02X OUT=%02X, maxpkt=%d",
                iface.id, inEp.address, outEp.address, inEp.maxPacketSize
            )
        )
        return RawIo(conn, iface, inEp, outEp)
    }

    private fun openLib(device: UsbDevice): SerialIo? {
        val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
        if (driver == null) {
            log("No usb-serial driver for this device.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        val port = driver.ports[0]
        port.open(conn)
        try {
            port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            log("setParameters: $e")
        }
        return LibIo(port)
    }
}
