package com.gamebowii.probe

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * GameBoWii 0.5
 *
 * Read-only tests of the GBFlash:
 *  - Probe: QUERY_FW_INFO only
 *  - Header GB/GBC and Header GBA: powers the cartridge and reads the first
 *    0x180 bytes of ROM (the header). No save or write commands exist here.
 */
class MainActivity : Activity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.gamebowii.probe.USB_PERMISSION"
        private const val VID_CH340 = 0x1A86
        private const val REQ_PICK_SAVE = 77
        private const val EMU_PACKAGE = "it.dbtecno.pizzaboypro"
        private const val EMU_ACTIVITY = "it.dbtecno.pizzaboypro.MainActivity"
    }

    private val LOGO_BYTES = intArrayOf(0xCE,0xED,0x66,0x66,0xCC,0x0D,0x00,0x0B,0x03,0x73,0x00,0x83,0x00,0x0C,0x00,0x0D,0x00,0x08,0x11,0x1F,0x88,0x89,0x00,0x0E,0xDC,0xCC,0x6E,0xE6,0xDD,0xDD,0xD9,0x99,0xBB,0xBB,0x67,0x63,0x6E,0x0E,0xEC,0xCC,0xDD,0xDC,0x99,0x9F,0xBB,0xB9,0x33,0x3E).map { it.toByte() }.toByteArray()

    private enum class Job { PROBE_RAW, HEADER_GB, HEADER_GBA, PROBE_LIB, DUMP_GB, WRITE_SAVE }

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var usbManager: UsbManager
    private var pendingJob: Job? = null

    @Volatile
    private var running = false

    private var lastPubUri: Uri? = null
    private var lastRomUri: Uri? = null
    private var lastRomPath: String? = null
    private var pendingSave: ByteArray? = null

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val job = pendingJob
            if (granted && job != null) startJob(job) else log("USB permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        // Needed to hand a file:// path to the emulator app.
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF101418.toInt())
        root.setPadding(48, 32, 48, 32)

        val title = TextView(this)
        title.text = "GameBoWii 0.5 - GBFlash\n" +
            "Unplug the GBFlash before inserting or removing a cartridge.\n" +
            "Writes to the cartridge only happen after you confirm them."
        title.textSize = 22f
        title.setTextColor(Color.WHITE)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val b1 = makeButton("Probe", Job.PROBE_RAW)
        val b5 = makeButton("Dump ROM+save GB/GBC", Job.DUMP_GB)
        val b6 = makeActionButton("Open ROM (file)") { launchEmulator(true) }
        val b7 = makeActionButton("Open ROM (content)") { launchEmulator(false) }
        val b8 = makeActionButton("Write save to cartridge") { pickSaveFile() }
        val b2 = makeButton("Header GB/GBC", Job.HEADER_GB)
        val b3 = makeButton("Header GBA", Job.HEADER_GBA)
        val b4 = makeButton("Probe (lib)", Job.PROBE_LIB)
        buttons.addView(b1)
        buttons.addView(b5)
        buttons.addView(b6)
        buttons.addView(b7)
        buttons.addView(b8)
        buttons.addView(b2)
        buttons.addView(b3)
        buttons.addView(b4)
        val buttonsScroll = HorizontalScrollView(this)
        buttonsScroll.addView(buttons)

        scroll = ScrollView(this)
        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 18f
        logView.setTextColor(0xFFB8F3B8.toInt())
        scroll.addView(logView)

        root.addView(title)
        root.addView(buttonsScroll)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        b1.requestFocus()
        if (Build.VERSION.SDK_INT in 23..28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        ContextCompat.registerReceiver(
            this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        log("Ready. 'Probe' = identify the GBFlash (no cartridge needed).")
        log("Log file: ${File(getExternalFilesDir(null), "probe_log.txt").absolutePath}")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(permissionReceiver)
        } catch (e: Exception) {
        }
    }

    private fun makeButton(label: String, job: Job): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { startJob(job) }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun makeActionButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        try {
            File(getExternalFilesDir(null), "probe_log.txt").appendText(msg + "\n")
        } catch (e: Exception) {
        }
    }

    private fun startJob(job: Job) {
        if (running) {
            log("Already running.")
            return
        }
        val device = usbManager.deviceList.values.firstOrNull { it.vendorId == VID_CH340 }
        if (device == null) {
            log("No 1A86 (CH340) device found. USB devices seen: ${usbManager.deviceList.size}")
            for (d in usbManager.deviceList.values) {
                log(String.format("  %04X:%04X", d.vendorId, d.productId))
            }
            return
        }
        if (!usbManager.hasPermission(device)) {
            pendingJob = job
            log("Requesting USB permission - accept the dialog on the TV.")
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), flags
            )
            usbManager.requestPermission(device, pi)
            return
        }
        running = true
        Thread {
            try {
                runJob(job, device)
            } catch (e: Exception) {
                log("ERROR: $e")
            } finally {
                running = false
            }
        }.start()
    }

    private fun runJob(job: Job, device: UsbDevice) {
        log("")
        log("--- $job ---")
        val io: SerialIo = (if (job == Job.PROBE_LIB) openLib(device) else openRaw(device)) ?: return
        try {
            val gb = GbFlash(io) { s -> log(s) }
            when (job) {
                Job.PROBE_RAW, Job.PROBE_LIB -> {
                    if (gb.queryFw()) log("RESULT: PASS - GBFlash answered QUERY_FW_INFO.")
                }
                Job.HEADER_GB -> readHeader(gb, true)
                Job.HEADER_GBA -> readHeader(gb, false)
                Job.DUMP_GB -> dumpCart(gb)
                Job.WRITE_SAVE -> writeSaveJob(gb)
            }
        } finally {
            io.close()
            log("Done.")
        }
    }

    private fun readHeader(gb: GbFlash, dmg: Boolean) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(dmg)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(dmg)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            try {
                File(getExternalFilesDir(null), "header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            val from = if (dmg) 0x100 else 0xA0
            val count = if (dmg) 0x50 else 0x20
            var off = from
            while (off < from + count) {
                log(String.format("%03X: ", off) + hexLine(h, off, 16))
                off += 16
            }
            val lines = if (dmg) describeGbHeader(h) else describeGbaHeader(h)
            for (l in lines) log(l)
            log("RESULT: header read OK.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }


    /** Copies a dump into the visible folder Download/GameBoWii. Returns a description or null. */
    private fun publishToDownloads(fileName: String, data: ByteArray): String? {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val rel = "Download/GameBoWii"
                var found: Uri? = null
                contentResolver.query(
                    collection, arrayOf(MediaStore.Downloads._ID),
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    arrayOf(fileName, "$rel/"), null
                )?.use { c ->
                    if (c.moveToFirst()) found = ContentUris.withAppendedId(collection, c.getLong(0))
                }
                var written = false
                val existing = found
                if (existing != null) {
                    try {
                        contentResolver.openOutputStream(existing, "wt")?.use { it.write(data) }
                        written = true
                    } catch (e: Exception) {
                        written = false
                    }
                }
                if (!written) {
                    val values = ContentValues()
                    values.put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    values.put(MediaStore.Downloads.RELATIVE_PATH, rel)
                    val uri = contentResolver.insert(collection, values) ?: return null
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(data) }
                    found = uri
                }
                lastPubUri = found
                return "Download/GameBoWii/$fileName"
            } else {
                if (Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    log("No storage permission - accept it and dump again to get the copy in Download/GameBoWii.")
                    return null
                }
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "GameBoWii")
                dir.mkdirs()
                File(dir, fileName).writeBytes(data)
                lastPubUri = Uri.fromFile(File(dir, fileName))
                return "Download/GameBoWii/$fileName"
            }
        } catch (e: Exception) {
            log("Could not copy $fileName to Download/GameBoWii: $e")
            return null
        }
    }

    private fun dumpCart(gb: GbFlash) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(true)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(true)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            for (l in describeGbHeader(h)) log(l)
            try {
                File(getExternalFilesDir(null), "last_header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            var logoOk = true
            for (i in 0 until 48) if (h[0x104 + i] != LOGO_BYTES[i]) logoOk = false
            if (!logoOk) {
                log("RESULT: no valid GB cartridge detected - aborting.")
                return
            }
            var name = ""
            for (i in 0x134..0x143) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "game"
            val cgb = (h[0x143].toInt() and 0xFF)
            val ext = if (cgb == 0x80 || cgb == 0xC0) "gbc" else "gb"
            var lastPct = -10
            val rom = gb.dumpRom(h) { pct ->
                if (pct >= lastPct + 10) {
                    lastPct = pct
                    log("ROM $pct%")
                }
            }
            if (rom == null) {
                log("RESULT: ROM dump FAILED.")
                return
            }
            var sum = 0
            for (i in rom.indices) if (i != 0x14E && i != 0x14F) sum += rom[i].toInt() and 0xFF
            sum = sum and 0xFFFF
            val stored = ((rom[0x14E].toInt() and 0xFF) shl 8) or (rom[0x14F].toInt() and 0xFF)
            val dir = getExternalFilesDir(null)
            val romFile = File(dir, "$name.$ext")
            romFile.writeBytes(rom)
            log("ROM saved: ${romFile.absolutePath} (${rom.size} bytes)")
            val romPub = publishToDownloads("$name.$ext", rom)
            if (romPub != null) {
                log("ROM copy: $romPub")
                lastRomUri = lastPubUri
                lastRomPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath +
                    "/GameBoWii/$name.$ext"
            }
            log(String.format("Global checksum: stored %04X, computed %04X -> %s", stored, sum,
                if (stored == sum) "OK, ROM is verified" else "MISMATCH (retry; a few games have bad checksums)"))
            lastPct = -10
            val sav = gb.dumpSave(h) { pct ->
                if (pct >= lastPct + 50) {
                    lastPct = pct
                    log("Save read $pct%")
                }
            }
            if (sav == null) {
                log("RESULT: save read FAILED (ROM file is still saved).")
            } else if (sav.isNotEmpty()) {
                val savFile = File(dir, "$name.sav")
                savFile.writeBytes(sav)
                log("Save saved: ${savFile.absolutePath} (${sav.size} bytes, two reads identical)")
                val savPub = publishToDownloads("$name.sav", sav)
                if (savPub != null) log("Save copy: $savPub")
            }
            log("RESULT: dump finished. Opening the emulator...")
            runOnUiThread { launchEmulator(true) }
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun launchEmulator(useFile: Boolean) {
        val path = lastRomPath
        val cUri = lastRomUri
        val uri: Uri? = if (useFile) (if (path != null) Uri.fromFile(File(path)) else null) else cUri
        if (uri == null) {
            log("No ROM has been dumped yet in this session.")
            return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.component = ComponentName(EMU_PACKAGE, EMU_ACTIVITY)
            i.data = uri
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
            log("Opened the emulator with $uri")
        } catch (e: Exception) {
            log("Could not open the emulator: $e")
        }
    }

    private fun pickSaveFile() {
        val hf = File(getExternalFilesDir(null), "last_header.bin")
        if (!hf.exists()) {
            log("Dump the cartridge first (it records which cartridge this is).")
            return
        }
        log("Pick the save file to write to the cartridge...")
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, REQ_PICK_SAVE)
        } catch (e: Exception) {
            log("No file picker available on this device: $e")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_SAVE || resultCode != RESULT_OK) return
        val picked: Uri = data?.data ?: return
        val bytes: ByteArray = try {
            contentResolver.openInputStream(picked)?.use { it.readBytes() } ?: return
        } catch (e: Exception) {
            log("Could not read the selected file: $e")
            return
        }
        val h = try {
            File(getExternalFilesDir(null), "last_header.bin").readBytes()
        } catch (e: Exception) {
            log("Dump the cartridge first.")
            return
        }
        val expected = saveSizeFor(h)
        val title = describeGbHeader(h).firstOrNull { it.startsWith("Title") } ?: ""
        if (expected == 0 || bytes.size != expected) {
            log("The save file is ${bytes.size} bytes but this cartridge needs $expected. Nothing will be written.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Εγγραφή save στο cartridge")
            .setMessage(
                title + "\n\nΘα ΑΝΤΙΚΑΤΑΣΤΑΘΕΙ το save που υπάρχει τώρα στο cartridge με το αρχείο που διάλεξες (" +
                    bytes.size + " bytes).\n\nΠρώτα θα φυλαχθεί αντίγραφο του τωρινού save στο Download/GameBoWii. " +
                    "Μετά την εγγραφή γίνεται έλεγχος. Να συνεχίσω;"
            )
            .setNegativeButton("Ακύρωση") { _, _ -> log("Cancelled. Nothing was written.") }
            .setPositiveButton("Γράψε το save") { _, _ ->
                pendingSave = bytes
                startJob(Job.WRITE_SAVE)
            }
            .show()
    }

    private fun writeSaveJob(gb: GbFlash) {
        val data = pendingSave
        pendingSave = null
        if (data == null) {
            log("No save selected.")
            return
        }
        if (!gb.queryFw()) return
        try {
            val saved = try {
                File(getExternalFilesDir(null), "last_header.bin").readBytes()
            } catch (e: Exception) {
                log("Dump the cartridge first.")
                return
            }
            if (!gb.setMode(true)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(true)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED. Nothing written.")
                return
            }
            for (i in 0x134..0x14F) {
                if (h[i] != saved[i]) {
                    log("RESULT: this is not the cartridge that was dumped. Nothing written.")
                    return
                }
            }
            log("Cartridge matches the dump. Backing up the current save...")
            val old = gb.dumpSave(h) { }
            if (old == null || old.isEmpty()) {
                log("RESULT: could not back up the current save. Nothing written.")
                return
            }
            var name = ""
            for (i in 0x134..0x143) {
                val c = h[i].toInt() and 0xFF
                if (c == 0) break
                name += if (c in 48..57 || c in 65..90 || c in 97..122) c.toChar() else '_'
            }
            if (name.isEmpty()) name = "game"
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val backupName = "backup-$name-$stamp.sav"
            try {
                File(getExternalFilesDir(null), backupName).writeBytes(old)
            } catch (e: Exception) {
                log("RESULT: could not store the backup. Nothing written.")
                return
            }
            val pub = publishToDownloads(backupName, old)
            if (pub == null) log("Note: the visible backup copy failed; the backup is in the app folder.")
            else log("Backup saved: $pub")
            log("Writing the save...")
            var last = -25
            val ok = gb.writeSave(h, data) { pct ->
                if (pct >= last + 25) {
                    last = pct
                    log("Save write $pct%")
                }
            }
            if (ok) log("RESULT: save written and verified.")
            else log("RESULT: save write FAILED. Your previous save is in $backupName - write it back with this same button.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun openRaw(device: UsbDevice): SerialIo? {
        var iface: UsbInterface? = null
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            var ein: UsbEndpoint? = null
            var eout: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) ein = ep else eout = ep
                }
            }
            if (ein != null && eout != null) {
                iface = itf
                inEp = ein
                outEp = eout
                break
            }
        }
        if (iface == null || inEp == null || outEp == null) {
            log("No bulk IN/OUT endpoints found.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        if (!conn.claimInterface(iface, true)) {
            log("claimInterface failed.")
            conn.close()
            return null
        }
        log(
            String.format(
                "Raw USB: interface %d, IN=%02X OUT=%02X, maxpkt=%d",
                iface.id, inEp.address, outEp.address, inEp.maxPacketSize
            )
        )
        return RawIo(conn, iface, inEp, outEp)
    }

    private fun openLib(device: UsbDevice): SerialIo? {
        val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
        if (driver == null) {
            log("No usb-serial driver for this device.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        val port = driver.ports[0]
        port.open(conn)
        try {
            port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            log("setParameters: $e")
        }
        return LibIo(port)
    }
}
