package com.gamebowii.probe

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.File

/**
 * GameBoWii probe 0.2
 *
 * Read-only tests of the GBFlash:
 *  - Probe: QUERY_FW_INFO only
 *  - Header GB/GBC and Header GBA: powers the cartridge and reads the first
 *    0x180 bytes of ROM (the header). No save or write commands exist here.
 */
class MainActivity : Activity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.gamebowii.probe.USB_PERMISSION"
        private const val VID_CH340 = 0x1A86
    }

    private enum class Job { PROBE_RAW, HEADER_GB, HEADER_GBA, PROBE_LIB }

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var usbManager: UsbManager
    private var pendingJob: Job? = null

    @Volatile
    private var running = false

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val job = pendingJob
            if (granted && job != null) startJob(job) else log("USB permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF101418.toInt())
        root.setPadding(48, 32, 48, 32)

        val title = TextView(this)
        title.text = "GameBoWii probe 0.3 - GBFlash (read-only)\n" +
            "Unplug the GBFlash before inserting or removing a cartridge."
        title.textSize = 22f
        title.setTextColor(Color.WHITE)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val b1 = makeButton("Probe", Job.PROBE_RAW)
        val b2 = makeButton("Header GB/GBC", Job.HEADER_GB)
        val b3 = makeButton("Header GBA", Job.HEADER_GBA)
        val b4 = makeButton("Probe (lib)", Job.PROBE_LIB)
        buttons.addView(b1)
        buttons.addView(b2)
        buttons.addView(b3)
        buttons.addView(b4)
        val buttonsScroll = HorizontalScrollView(this)
        buttonsScroll.addView(buttons)

        scroll = ScrollView(this)
        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 18f
        logView.setTextColor(0xFFB8F3B8.toInt())
        scroll.addView(logView)

        root.addView(title)
        root.addView(buttonsScroll)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        b1.requestFocus()

        ContextCompat.registerReceiver(
            this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        log("Ready. 'Probe' = identify the GBFlash (no cartridge needed).")
        log("Log file: ${File(getExternalFilesDir(null), "probe_log.txt").absolutePath}")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(permissionReceiver)
        } catch (e: Exception) {
        }
    }

    private fun makeButton(label: String, job: Job): Button {
        val b = Button(this)
        b.text = label
        b.isFocusable = true
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF37474F.toInt())
        b.setPadding(32, 16, 32, 16)
        b.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
        }
        b.setOnClickListener { startJob(job) }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 16, 0)
        b.layoutParams = lp
        return b
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        try {
            File(getExternalFilesDir(null), "probe_log.txt").appendText(msg + "\n")
        } catch (e: Exception) {
        }
    }

    private fun startJob(job: Job) {
        if (running) {
            log("Already running.")
            return
        }
        val device = usbManager.deviceList.values.firstOrNull { it.vendorId == VID_CH340 }
        if (device == null) {
            log("No 1A86 (CH340) device found. USB devices seen: ${usbManager.deviceList.size}")
            for (d in usbManager.deviceList.values) {
                log(String.format("  %04X:%04X", d.vendorId, d.productId))
            }
            return
        }
        if (!usbManager.hasPermission(device)) {
            pendingJob = job
            log("Requesting USB permission - accept the dialog on the TV.")
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), flags
            )
            usbManager.requestPermission(device, pi)
            return
        }
        running = true
        Thread {
            try {
                runJob(job, device)
            } catch (e: Exception) {
                log("ERROR: $e")
            } finally {
                running = false
            }
        }.start()
    }

    private fun runJob(job: Job, device: UsbDevice) {
        log("")
        log("--- $job ---")
        val io: SerialIo = (if (job == Job.PROBE_LIB) openLib(device) else openRaw(device)) ?: return
        try {
            val gb = GbFlash(io) { s -> log(s) }
            when (job) {
                Job.PROBE_RAW, Job.PROBE_LIB -> {
                    if (gb.queryFw()) log("RESULT: PASS - GBFlash answered QUERY_FW_INFO.")
                }
                Job.HEADER_GB -> readHeader(gb, true)
                Job.HEADER_GBA -> readHeader(gb, false)
            }
        } finally {
            io.close()
            log("Done.")
        }
    }

    private fun readHeader(gb: GbFlash, dmg: Boolean) {
        if (!gb.queryFw()) return
        try {
            if (!gb.setMode(dmg)) {
                log("Could not power/select the cartridge slot.")
                return
            }
            val h = gb.readHeader(dmg)
            if (h == null || h.size < 0x180) {
                log("RESULT: header read FAILED.")
                return
            }
            try {
                File(getExternalFilesDir(null), "header.bin").writeBytes(h)
            } catch (e: Exception) {
            }
            val from = if (dmg) 0x100 else 0xA0
            val count = if (dmg) 0x50 else 0x20
            var off = from
            while (off < from + count) {
                log(String.format("%03X: ", off) + hexLine(h, off, 16))
                off += 16
            }
            val lines = if (dmg) describeGbHeader(h) else describeGbaHeader(h)
            for (l in lines) log(l)
            log("RESULT: header read OK.")
        } finally {
            try {
                gb.powerOff()
            } catch (e: Exception) {
            }
        }
    }

    private fun openRaw(device: UsbDevice): SerialIo? {
        var iface: UsbInterface? = null
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            var ein: UsbEndpoint? = null
            var eout: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) ein = ep else eout = ep
                }
            }
            if (ein != null && eout != null) {
                iface = itf
                inEp = ein
                outEp = eout
                break
            }
        }
        if (iface == null || inEp == null || outEp == null) {
            log("No bulk IN/OUT endpoints found.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        if (!conn.claimInterface(iface, true)) {
            log("claimInterface failed.")
            conn.close()
            return null
        }
        log(
            String.format(
                "Raw USB: interface %d, IN=%02X OUT=%02X, maxpkt=%d",
                iface.id, inEp.address, outEp.address, inEp.maxPacketSize
            )
        )
        return RawIo(conn, iface, inEp, outEp)
    }

    private fun openLib(device: UsbDevice): SerialIo? {
        val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
        if (driver == null) {
            log("No usb-serial driver for this device.")
            return null
        }
        val conn = usbManager.openDevice(device)
        if (conn == null) {
            log("openDevice failed.")
            return null
        }
        val port = driver.ports[0]
        port.open(conn)
        try {
            port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            log("setParameters: $e")
        }
        return LibIo(port)
    }
}
