package com.gamebowii.probe

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.File

/**
 * GameBoWii probe 0.1
 *
 * Sends exactly ONE command to the GBFlash: QUERY_FW_INFO (0xA1), the same
 * command FlashGBX uses to identify the device. No cartridge, save, write or
 * firmware commands are sent.
 */
class MainActivity : Activity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.gamebowii.probe.USB_PERMISSION"
        private const val VID_CH340 = 0x1A86
        private const val CMD_QUERY_FW_INFO = 0xA1
        private const val IO_TIMEOUT_MS = 1500
    }

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var usbManager: UsbManager
    private var pendingBaud = 2000000

    @Volatile
    private var running = false

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (granted) startProbe(pendingBaud) else log("USB permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(48, 32, 48, 32)
        }
        val title = TextView(this).apply {
            text = "GameBoWii probe 0.1 - GBFlash identification\n(sends only QUERY_FW_INFO, no cartridge access)"
            textSize = 22f
            setTextColor(Color.WHITE)
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b1 = Button(this).apply {
            text = "Probe (2 Mbaud)"
            setOnClickListener { startProbe(2000000) }
        }
        val b2 = Button(this).apply {
            text = "Probe (115200)"
            setOnClickListener { startProbe(115200) }
        }
        buttons.addView(b1)
        buttons.addView(b2)

        scroll = ScrollView(this)
        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 18f
            setTextColor(0xFFB8F3B8.toInt())
        }
        scroll.addView(logView)

        root.addView(title)
        root.addView(buttons)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        b1.requestFocus()

        ContextCompat.registerReceiver(
            this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        log("Connect the GBFlash (no cartridge inserted), then press 'Probe'.")
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(permissionReceiver)
        } catch (e: Exception) {
        }
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        try {
            File(getExternalFilesDir(null), "probe_log.txt").appendText(msg + "\n")
        } catch (e: Exception) {
        }
    }

    private fun hex(b: ByteArray, off: Int, len: Int): String =
        (off until off + len).joinToString(" ") { String.format("%02X", b[it]) }

    private fun startProbe(baud: Int) {
        if (running) {
            log("Probe already running.")
            return
        }
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
            .filter { it.device.vendorId == VID_CH340 }
        if (drivers.isEmpty()) {
            log("No 1A86 (CH340) device found. USB devices seen: ${usbManager.deviceList.size}")
            for (d in usbManager.deviceList.values) {
                log(String.format("  %04X:%04X", d.vendorId, d.productId))
            }
            return
        }
        val driver = drivers[0]
        val device = driver.device
        if (!usbManager.hasPermission(device)) {
            pendingBaud = baud
            log("Requesting USB permission - accept the dialog on the TV.")
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), flags
            )
            usbManager.requestPermission(device, pi)
            return
        }
        running = true
        Thread {
            try {
                runProbe(driver, baud)
            } catch (e: Exception) {
                log("ERROR: $e")
            } finally {
                running = false
            }
        }.start()
    }

    private fun runProbe(driver: UsbSerialDriver, baud: Int) {
        log("")
        log("--- PROBE (baud $baud) ---")
        val device = driver.device
        log(
            String.format(
                "Device %04X:%04X driver=%s ports=%d",
                device.vendorId, device.productId, driver.javaClass.simpleName, driver.ports.size
            )
        )
        val connection = usbManager.openDevice(device)
        if (connection == null) {
            log("openDevice failed (permission?)")
            return
        }
        val port = driver.ports[0]
        try {
            port.open(connection)
            try {
                port.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                log("setParameters OK")
            } catch (e: Exception) {
                log("setParameters failed: $e")
            }
            try {
                port.setDTR(true)
                port.setRTS(true)
            } catch (e: Exception) {
                log("DTR/RTS: $e")
            }
            Thread.sleep(100)
            try {
                port.purgeHwBuffers(true, true)
            } catch (e: Exception) {
                log("purge: $e")
            }

            port.write(byteArrayOf(CMD_QUERY_FW_INFO.toByte()), IO_TIMEOUT_MS)
            log("Sent QUERY_FW_INFO (0xA1)")

            val acc = ByteArray(128)
            var have = 0
            val tmp = ByteArray(64)

            fun fill(want: Int): Boolean {
                var empty = 0
                while (have < want) {
                    val n = port.read(tmp, IO_TIMEOUT_MS)
                    if (n <= 0) {
                        empty++
                        if (empty >= 2) {
                            log("Timeout: no reply (have $have of $want bytes)")
                            return false
                        }
                        continue
                    }
                    val c = minOf(n, acc.size - have)
                    System.arraycopy(tmp, 0, acc, have, c)
                    have += c
                    log("rx $n byte(s)")
                }
                return true
            }

            if (!fill(1)) return
            val size = acc[0].toInt() and 0xFF
            log("Reply size byte = $size (FlashGBX expects 8)")
            if (size != 8) {
                log("raw: " + hex(acc, 0, have))
                log("RESULT: unexpected reply - not a recognised GBFlash answer.")
                return
            }
            if (!fill(9)) return

            val cfw = (acc[1].toInt() and 0xFF).toChar()
            val fwVer = ((acc[2].toInt() and 0xFF) shl 8) or (acc[3].toInt() and 0xFF)
            val pcb = acc[4].toInt() and 0xFF
            val ts = ((acc[5].toLong() and 0xFF) shl 24) or ((acc[6].toLong() and 0xFF) shl 16) or
                ((acc[7].toLong() and 0xFF) shl 8) or (acc[8].toLong() and 0xFF)
            log("info: " + hex(acc, 1, 8))
            log("cfw_id='${if (cfw.code in 32..126) cfw else '?'}' fw_ver=$fwVer pcb_ver=$pcb build_ts=$ts")

            if (cfw == 'L' && fwVer >= 12) {
                if (!fill(10)) return
                val nlen = acc[9].toInt() and 0xFF
                if (nlen > 40) {
                    log("name length $nlen looks wrong")
                    return
                }
                if (!fill(10 + nlen + 2)) return
                val name = String(CharArray(nlen) {
                    val c = acc[10 + it].toInt() and 0xFF
                    if (c in 32..126) c.toChar() else '.'
                })
                val f1 = acc[10 + nlen].toInt() and 0xFF
                val f2 = acc[11 + nlen].toInt() and 0xFF
                log("name=\"$name\" cart_power_ctrl=${f1 and 1} presence_sw=${(f1 shr 1) and 1} mode_sw=${(f1 shr 2) and 1}")
                log("bootloader_reset=${f2 and 1} unregistered=${(f2 shr 7) and 1}")
            }
            log("full reply: " + hex(acc, 0, have))
            log("RESULT: PASS - GBFlash answered QUERY_FW_INFO.")
        } finally {
            try {
                port.close()
            } catch (e: Exception) {
            }
            log("Probe ended. Only QUERY_FW_INFO was sent.")
        }
    }
}
