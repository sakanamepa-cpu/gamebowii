package com.gamebowii.probe

/**
 * GBFlash (FlashGBX "L" firmware, fw >= 12) protocol, read-only subset.
 * Command values and sequences follow FlashGBX LK_Device.py.
 * Only identification, cartridge power and ROM header reads are implemented.
 */
class GbFlash(private val io: SerialIo, private val log: (String) -> Unit) {

    companion object {
        const val IO_TIMEOUT = 1500

        const val CMD_QUERY_FW_INFO = 0xA1
        const val CMD_SET_MODE_AGB = 0xA2
        const val CMD_SET_MODE_DMG = 0xA3
        const val CMD_SET_VOLTAGE_3_3V = 0xA4
        const val CMD_SET_VOLTAGE_5V = 0xA5
        const val CMD_SET_VARIABLE = 0xA6
        const val CMD_DISABLE_PULLUPS = 0xAC
        const val CMD_DMG_CART_READ = 0xB1
        const val CMD_DMG_CART_WRITE = 0xB2
        const val CMD_DMG_MBC_RESET = 0xB4
        const val CMD_AGB_CART_READ = 0xC1
        const val CMD_AGB_BOOTUP = 0xC9
        const val CMD_CART_PWR_ON = 0xF2
        const val CMD_CART_PWR_OFF = 0xF3
        const val CMD_QUERY_CART_PWR = 0xF4

        // Variable ids (the size selects the table: 1 = 8-bit, 2 = 16-bit, 4 = 32-bit)
        const val VAR_ADDRESS = 0x00
        const val VAR_TRANSFER_SIZE = 0x00
        const val VAR_CART_MODE = 0x00
        const val VAR_DMG_ACCESS_MODE = 0x01
        const val VAR_DMG_READ_CS_PULSE = 0x08
        const val VAR_DMG_WRITE_CS_PULSE = 0x09
        const val VAR_DMG_READ_METHOD = 0x0B
        const val VAR_AGB_READ_METHOD = 0x0C
        const val VAR_AGB_IRQ_ENABLED = 0x10
    }

    var fwVer = 0
        private set

    private var rx = ByteArray(0)
    private val tmp = ByteArray(256)

    // ---------------------------------------------------------------- I/O

    private fun readExact(n: Int, timeoutMs: Int = IO_TIMEOUT): ByteArray? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (rx.size < n) {
            val left = (deadline - System.currentTimeMillis()).toInt()
            if (left <= 0) return null
            val got = io.read(tmp, left)
            if (got > 0) rx = rx + tmp.copyOf(got)
        }
        val out = rx.copyOfRange(0, n)
        rx = rx.copyOfRange(n, rx.size)
        return out
    }

    fun drain() {
        rx = ByteArray(0)
        var loops = 0
        while (loops < 20) {
            val got = try {
                io.read(tmp, 100)
            } catch (e: Exception) {
                0
            }
            if (got <= 0) break
            loops++
        }
    }

    private fun send(code: Int) {
        io.write(byteArrayOf(code.toByte()), IO_TIMEOUT)
    }

    private fun hex2(v: Int): String = String.format("%02X", v and 0xFF)

    /** Sends a single command byte and waits for the firmware ACK (0x01 or 0x03). */
    private fun cmd(code: Int, name: String): Boolean {
        send(code)
        val r = readExact(1)
        if (r == null) {
            log("$name: no ACK (timeout)")
            return false
        }
        val v = r[0].toInt() and 0xFF
        if (v != 1 && v != 3) {
            log("$name: unexpected ACK ${hex2(v)}")
            return false
        }
        return true
    }

    private fun setVar(sizeBytes: Int, key: Int, value: Int, name: String): Boolean {
        val b = ByteArray(10)
        b[0] = CMD_SET_VARIABLE.toByte()
        b[1] = sizeBytes.toByte()
        b[2] = (key ushr 24).toByte()
        b[3] = (key ushr 16).toByte()
        b[4] = (key ushr 8).toByte()
        b[5] = key.toByte()
        b[6] = (value ushr 24).toByte()
        b[7] = (value ushr 16).toByte()
        b[8] = (value ushr 8).toByte()
        b[9] = value.toByte()
        io.write(b, IO_TIMEOUT)
        val r = readExact(1)
        if (r == null) {
            log("SET_VARIABLE $name: no ACK (timeout)")
            return false
        }
        val v = r[0].toInt() and 0xFF
        if (v != 1 && v != 3) {
            log("SET_VARIABLE $name: unexpected ACK ${hex2(v)}")
            return false
        }
        return true
    }

    // ---------------------------------------------------- identification

    fun queryFw(): Boolean {
        drain()
        send(CMD_QUERY_FW_INFO)
        val s = readExact(1)
        if (s == null) {
            log("QUERY_FW_INFO: no reply (timeout)")
            return false
        }
        val size = s[0].toInt() and 0xFF
        if (size != 8) {
            log("QUERY_FW_INFO: size byte ${hex2(size)} (expected 08)")
            return false
        }
        val d = readExact(8)
        if (d == null) {
            log("QUERY_FW_INFO: short reply")
            return false
        }
        val cfw = (d[0].toInt() and 0xFF).toChar()
        fwVer = ((d[1].toInt() and 0xFF) shl 8) or (d[2].toInt() and 0xFF)
        val pcb = d[3].toInt() and 0xFF
        var name = ""
        if (cfw == 'L' && fwVer >= 12) {
            val nl = readExact(1)
            if (nl == null) {
                log("QUERY_FW_INFO: no name length")
                return false
            }
            val nameBytes = readExact(nl[0].toInt() and 0xFF)
            val flags = readExact(2)
            if (nameBytes == null || flags == null) {
                log("QUERY_FW_INFO: short name/flags")
                return false
            }
            name = String(CharArray(nameBytes.size) {
                val c = nameBytes[it].toInt() and 0xFF
                if (c in 32..126) c.toChar() else ' '
            }).trim()
        }
        log("device \"$name\" firmware $cfw$fwVer pcb_ver=$pcb")
        if (cfw != 'L' || fwVer < 12) {
            log("Unsupported firmware (need L12 or newer).")
            return false
        }
        return true
    }

    // ------------------------------------------------- cartridge power

    fun setMode(dmg: Boolean): Boolean {
        drain()
        if (!cmd(CMD_CART_PWR_OFF, "CART_PWR_OFF")) return false
        if (dmg) {
            if (!cmd(CMD_SET_MODE_DMG, "SET_MODE_DMG")) return false
            if (!cmd(CMD_SET_VOLTAGE_5V, "SET_VOLTAGE_5V")) return false
            if (!setVar(1, VAR_DMG_READ_METHOD, 1, "DMG_READ_METHOD")) return false
            if (!setVar(1, VAR_CART_MODE, 1, "CART_MODE")) return false
        } else {
            if (!cmd(CMD_SET_MODE_AGB, "SET_MODE_AGB")) return false
            if (!cmd(CMD_SET_VOLTAGE_3_3V, "SET_VOLTAGE_3_3V")) return false
            if (!setVar(1, VAR_AGB_READ_METHOD, 0, "AGB_READ_METHOD")) return false
            if (!setVar(1, VAR_CART_MODE, 2, "CART_MODE")) return false
            if (!setVar(1, VAR_AGB_IRQ_ENABLED, 0, "AGB_IRQ_ENABLED")) return false
        }
        if (!setVar(4, VAR_ADDRESS, 0, "ADDRESS")) return false

        send(CMD_QUERY_CART_PWR)
        val st = readExact(1)
        if (st == null) {
            log("QUERY_CART_PWR: no reply")
            return false
        }
        if ((st[0].toInt() and 0xFF) == 0) {
            if (!cmd(if (dmg) CMD_SET_MODE_DMG else CMD_SET_MODE_AGB, "SET_MODE")) return false
            if (!cmd(CMD_CART_PWR_ON, "CART_PWR_ON")) return false
            Thread.sleep(100)
            send(CMD_QUERY_CART_PWR)
            val st2 = readExact(1)
            log("cartridge power state: ${if (st2 == null) "no reply" else hex2(st2[0].toInt())} (01 = on)")
            if (dmg) {
                if (!cmd(CMD_DMG_MBC_RESET, "DMG_MBC_RESET")) return false
            } else {
                if (!cmd(CMD_AGB_BOOTUP, "AGB_BOOTUP_SEQUENCE")) return false
            }
        }
        return true
    }

    fun powerOff() {
        cmd(CMD_CART_PWR_OFF, "CART_PWR_OFF")
    }

    // ------------------------------------------------------ ROM reads

    fun readRom(address: Int, length: Int, dmg: Boolean): ByteArray? {
        val chunk = 64
        val tsize = if (length < chunk) length else chunk
        val iterations = (length + chunk - 1) / chunk
        if (!setVar(2, VAR_TRANSFER_SIZE, tsize, "TRANSFER_SIZE")) return null
        if (dmg) {
            if (!setVar(4, VAR_ADDRESS, address, "ADDRESS")) return null
            if (!setVar(1, VAR_DMG_ACCESS_MODE, 1, "DMG_ACCESS_MODE")) return null
        } else {
            if (!setVar(4, VAR_ADDRESS, address ushr 1, "ADDRESS")) return null
        }
        val c = if (dmg) CMD_DMG_CART_READ else CMD_AGB_CART_READ
        var out = ByteArray(0)
        for (i in 0 until iterations) {
            send(c)
            val part = readExact(tsize)
            if (part == null) {
                log("ROM read: timeout in block $i of $iterations (got ${out.size} bytes)")
                return null
            }
            out = out + part
        }
        return out
    }

    // ------------------------------------------------ full dump (read-only)

    private var curChunk = 512

    private fun cartWrite(address: Int, value: Int): Boolean {
        val b = ByteArray(6)
        b[0] = CMD_DMG_CART_WRITE.toByte()
        b[1] = (address ushr 24).toByte()
        b[2] = (address ushr 16).toByte()
        b[3] = (address ushr 8).toByte()
        b[4] = address.toByte()
        b[5] = value.toByte()
        io.write(b, IO_TIMEOUT)
        val r = readExact(1)
        if (r == null) {
            log("MBC register write ${hex2(address ushr 8)}${hex2(address)}: no ACK")
            return false
        }
        val v = r[0].toInt() and 0xFF
        return v == 1 || v == 3
    }

    /** One transfer attempt with a given chunk size. Returns null on any failure. */
    private fun readStreamOnce(address: Int, length: Int, accessMode: Int, chunk: Int): ByteArray? {
        val tsize = if (length < chunk) length else chunk
        val iterations = (length + tsize - 1) / tsize
        if (!setVar(2, VAR_TRANSFER_SIZE, tsize, "TRANSFER_SIZE")) return null
        if (!setVar(4, VAR_ADDRESS, address, "ADDRESS")) return null
        if (!setVar(1, VAR_DMG_ACCESS_MODE, accessMode, "DMG_ACCESS_MODE")) return null
        val out = ByteArray(iterations * tsize)
        var pos = 0
        for (i in 0 until iterations) {
            send(CMD_DMG_CART_READ)
            val part = readExact(tsize, 3000) ?: return null
            System.arraycopy(part, 0, out, pos, tsize)
            pos += tsize
        }
        return if (out.size == length) out else out.copyOf(length)
    }

    /** Reads with automatic fallback to smaller chunks (512 -> 256 -> 128 -> 64). */
    private fun readStream(address: Int, length: Int, accessMode: Int): ByteArray? {
        var attempts = 0
        while (attempts < 12) {
            val r = readStreamOnce(address, length, accessMode, curChunk)
            if (r != null) return r
            drain()
            attempts++
            if (curChunk > 64) {
                curChunk = curChunk / 2
                log("transfer problem, chunk size reduced to $curChunk")
            }
        }
        return null
    }

    fun mapperOf(type: Int): String = when (type) {
        0x00, 0x08, 0x09 -> "NONE"
        0x01, 0x02, 0x03 -> "MBC1"
        0x05, 0x06 -> "MBC2"
        0x0F, 0x10, 0x11, 0x12, 0x13 -> "MBC3"
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E -> "MBC5"
        else -> "UNSUPPORTED"
    }

    private fun selectRomBank(mapper: String, bank: Int): Boolean = when (mapper) {
        "MBC1" -> cartWrite(0x2000, bank and 0x1F)
        "MBC2" -> cartWrite(0x2100, bank and 0x0F)
        "MBC3" -> cartWrite(0x2000, bank and 0x7F)
        "MBC5" -> cartWrite(0x2000, bank and 0xFF) && cartWrite(0x3000, (bank ushr 8) and 1)
        else -> true
    }

    /**
     * Dumps the whole ROM. The only commands sent to the cartridge besides reads are
     * the standard mapper bank-select register writes (they do not change ROM or save).
     */
    fun dumpRom(header: ByteArray, progress: (Int) -> Unit): ByteArray? {
        val type = header[0x147].toInt() and 0xFF
        val code = header[0x148].toInt() and 0xFF
        val mapper = mapperOf(type)
        if (mapper == "UNSUPPORTED") {
            log("Cartridge type ${hex2(type)} (${cartTypeName(type)}) is not supported yet.")
            return null
        }
        if (code > 8) {
            log("Unusual ROM size code ${hex2(code)} - not supported.")
            return null
        }
        val size = 0x8000 shl code
        val banks = size / 0x4000
        if (mapper == "MBC1" && banks > 32) {
            log("MBC1 with more than 512 KB (multi-cart/special wiring) is not supported yet.")
            return null
        }
        if (!cmd(CMD_DMG_MBC_RESET, "DMG_MBC_RESET")) return null
        if (!setVar(1, VAR_DMG_READ_CS_PULSE, 0, "DMG_READ_CS_PULSE")) return null
        if (!setVar(1, VAR_DMG_WRITE_CS_PULSE, 0, "DMG_WRITE_CS_PULSE")) return null
        val out = ByteArray(size)
        if (mapper == "NONE") {
            var pos = 0
            while (pos < size) {
                val n = if (size - pos > 0x4000) 0x4000 else size - pos
                val b = readStream(pos, n, 1) ?: run { log("ROM read failed at ${"%X".format(pos)}"); return null }
                System.arraycopy(b, 0, out, pos, n)
                pos += n
                progress(pos * 100 / size)
            }
            return out
        }
        for (bank in 0 until banks) {
            val addr: Int
            if (bank == 0) {
                addr = 0
            } else {
                if (!selectRomBank(mapper, bank)) { log("bank select failed at $bank"); return null }
                addr = 0x4000
            }
            val b = readStream(addr, 0x4000, 1) ?: run { log("ROM read failed in bank $bank"); return null }
            System.arraycopy(b, 0, out, bank * 0x4000, 0x4000)
            progress((bank + 1) * 100 / banks)
        }
        return out
    }

    /** Reads the battery save (SRAM) twice and requires both reads to match. No writes to the save. */
    fun dumpSave(header: ByteArray, progress: (Int) -> Unit): ByteArray? {
        val type = header[0x147].toInt() and 0xFF
        val mapper = mapperOf(type)
        val ramCode = header[0x149].toInt() and 0xFF
        var size = when (ramCode) { 1 -> 0x800; 2 -> 0x2000; 3 -> 0x8000; 4 -> 0x20000; 5 -> 0x10000; else -> 0 }
        if (mapper == "MBC2") size = 0x200
        if (size == 0) { log("This cartridge has no RAM/save."); return ByteArray(0) }
        val first = readRamOnce(mapper, size) ?: return null
        progress(50)
        val second = readRamOnce(mapper, size) ?: return null
        progress(100)
        if (!first.contentEquals(second)) {
            log("Save: two consecutive reads differ - not trustworthy.")
            return null
        }
        return first
    }

    private fun readRamOnce(mapper: String, size: Int): ByteArray? {
        val out = ByteArray(size)
        val bankSize = if (size < 0x2000) size else 0x2000
        val banks = size / bankSize
        if (mapper != "NONE") {
            if (!cartWrite(0x0000, 0x0A)) return null
            if (mapper == "MBC1" && banks > 1 && !cartWrite(0x6000, 1)) return null
        }
        var ok = true
        if (!setVar(1, VAR_DMG_READ_CS_PULSE, 1, "DMG_READ_CS_PULSE")) ok = false
        if (ok) {
            for (bank in 0 until banks) {
                if (mapper == "MBC1" || mapper == "MBC3" || mapper == "MBC5") {
                    if (!cartWrite(0x4000, bank and 0x0F)) { ok = false; break }
                }
                val b = readStream(0xA000, bankSize, 3)
                if (b == null) { log("Save read failed in bank $bank"); ok = false; break }
                System.arraycopy(b, 0, out, bank * bankSize, bankSize)
            }
        }
        // Always leave the cartridge RAM disabled again.
        setVar(1, VAR_DMG_READ_CS_PULSE, 0, "DMG_READ_CS_PULSE")
        if (mapper != "NONE") {
            if (mapper == "MBC1" && banks > 1) cartWrite(0x6000, 0)
            cartWrite(0x0000, 0x00)
        }
        return if (ok) out else null
    }

    /** Reads the first 0x180 bytes of the cartridge ROM (the header). */
    fun readHeader(dmg: Boolean): ByteArray? {
        if (!cmd(CMD_DISABLE_PULLUPS, "DISABLE_PULLUPS")) return null
        if (dmg) {
            if (!cmd(CMD_SET_VOLTAGE_5V, "SET_VOLTAGE_5V")) return null
            if (!cmd(CMD_DMG_MBC_RESET, "DMG_MBC_RESET")) return null
            if (!setVar(1, VAR_DMG_READ_CS_PULSE, 0, "DMG_READ_CS_PULSE")) return null
            if (!setVar(1, VAR_DMG_WRITE_CS_PULSE, 0, "DMG_WRITE_CS_PULSE")) return null
        } else {
            if (!cmd(CMD_SET_VOLTAGE_3_3V, "SET_VOLTAGE_3_3V")) return null
        }
        return readRom(0, 0x180, dmg)
    }
}

// ------------------------------------------------------------ header parsing

private val NINTENDO_LOGO = intArrayOf(
    0xCE, 0xED, 0x66, 0x66, 0xCC, 0x0D, 0x00, 0x0B, 0x03, 0x73, 0x00, 0x83, 0x00, 0x0C, 0x00, 0x0D,
    0x00, 0x08, 0x11, 0x1F, 0x88, 0x89, 0x00, 0x0E, 0xDC, 0xCC, 0x6E, 0xE6, 0xDD, 0xDD, 0xD9, 0x99,
    0xBB, 0xBB, 0x67, 0x63, 0x6E, 0x0E, 0xEC, 0xCC, 0xDD, 0xDC, 0x99, 0x9F, 0xBB, 0xB9, 0x33, 0x3E
)

private fun asciiAt(h: ByteArray, from: Int, len: Int): String {
    val sb = StringBuilder()
    for (i in from until from + len) {
        val c = h[i].toInt() and 0xFF
        if (c == 0) break
        sb.append(if (c in 32..126) c.toChar() else '.')
    }
    return sb.toString().trim()
}

fun hexLine(h: ByteArray, from: Int, len: Int): String {
    val sb = StringBuilder()
    for (i in from until from + len) {
        if (i > from) sb.append(' ')
        sb.append(String.format("%02X", h[i].toInt() and 0xFF))
    }
    return sb.toString()
}

fun cartTypeName(t: Int): String = when (t) {
    0x00 -> "ROM ONLY"
    0x01 -> "MBC1"
    0x02 -> "MBC1+RAM"
    0x03 -> "MBC1+RAM+BATTERY"
    0x05 -> "MBC2"
    0x06 -> "MBC2+BATTERY"
    0x08 -> "ROM+RAM"
    0x09 -> "ROM+RAM+BATTERY"
    0x0B -> "MMM01"
    0x0C -> "MMM01+RAM"
    0x0D -> "MMM01+RAM+BATTERY"
    0x0F -> "MBC3+TIMER+BATTERY"
    0x10 -> "MBC3+TIMER+RAM+BATTERY"
    0x11 -> "MBC3"
    0x12 -> "MBC3+RAM"
    0x13 -> "MBC3+RAM+BATTERY"
    0x19 -> "MBC5"
    0x1A -> "MBC5+RAM"
    0x1B -> "MBC5+RAM+BATTERY"
    0x1C -> "MBC5+RUMBLE"
    0x1D -> "MBC5+RUMBLE+RAM"
    0x1E -> "MBC5+RUMBLE+RAM+BATTERY"
    0x20 -> "MBC6"
    0x22 -> "MBC7+SENSOR+RUMBLE+RAM+BATTERY"
    0xFC -> "POCKET CAMERA"
    0xFD -> "BANDAI TAMA5"
    0xFE -> "HuC3"
    0xFF -> "HuC1+RAM+BATTERY"
    else -> "unknown (" + String.format("%02X", t) + ")"
}

private fun ramSizeText(code: Int): String = when (code) {
    0 -> "none"
    1 -> "2 KB"
    2 -> "8 KB"
    3 -> "32 KB (4 banks)"
    4 -> "128 KB (16 banks)"
    5 -> "64 KB (8 banks)"
    else -> "unknown (" + String.format("%02X", code) + ")"
}

fun describeGbHeader(h: ByteArray): List<String> {
    val lines = ArrayList<String>()
    var logoOk = true
    for (i in 0 until 48) {
        if ((h[0x104 + i].toInt() and 0xFF) != NINTENDO_LOGO[i]) logoOk = false
    }
    val cgb = h[0x143].toInt() and 0xFF
    val titleLen = if (cgb == 0x80 || cgb == 0xC0) 11 else 15
    val type = h[0x147].toInt() and 0xFF
    val romCode = h[0x148].toInt() and 0xFF
    val ramCode = h[0x149].toInt() and 0xFF
    var chk = 0
    for (i in 0x134..0x14C) chk = (chk - (h[i].toInt() and 0xFF) - 1) and 0xFF
    val chkStored = h[0x14D].toInt() and 0xFF

    lines.add("Nintendo logo: " + if (logoOk) "OK" else "NOT matching (cartridge not seated or not a GB cart?)")
    lines.add("Title: \"" + asciiAt(h, 0x134, titleLen) + "\"")
    lines.add("Game Boy Color flag: " + when (cgb) {
        0x80 -> "supports GBC (also runs on GB)"
        0xC0 -> "GBC only"
        else -> "no (plain GB)"
    })
    lines.add("Cartridge type: " + cartTypeName(type))
    lines.add(
        "ROM size: " + (if (romCode <= 8) (32 shl romCode).toString() + " KB" else "code " + String.format("%02X", romCode))
    )
    lines.add("RAM size: " + ramSizeText(ramCode))
    lines.add(
        "Header checksum: stored " + String.format("%02X", chkStored) + ", computed " +
            String.format("%02X", chk) + (if (chk == chkStored) " (OK)" else " (MISMATCH)")
    )
    return lines
}

fun describeGbaHeader(h: ByteArray): List<String> {
    val lines = ArrayList<String>()
    var chk = 0
    for (i in 0xA0..0xBC) chk -= (h[i].toInt() and 0xFF)
    chk = (chk - 0x19) and 0xFF
    val stored = h[0xBD].toInt() and 0xFF
    val fixed = h[0xB2].toInt() and 0xFF
    lines.add("Title: \"" + asciiAt(h, 0xA0, 12) + "\"")
    lines.add("Game code: " + asciiAt(h, 0xAC, 4) + "  Maker: " + asciiAt(h, 0xB0, 2))
    lines.add("Fixed byte 0xB2: " + String.format("%02X", fixed) + (if (fixed == 0x96) " (OK)" else " (expected 96)"))
    lines.add("Version: " + (h[0xBC].toInt() and 0xFF))
    lines.add(
        "Header checksum: stored " + String.format("%02X", stored) + ", computed " +
            String.format("%02X", chk) + (if (chk == stored) " (OK)" else " (MISMATCH)")
    )
    return lines
}
